using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace NPC夜晚会开门
{
	public class NPC夜晚会开门 : Mod
	{
		public override void Load()
		{
			On_NPC.AI_007_TownEntities += NPC_007_TownEntities_AI;
		}

		private void NPC_007_TownEntities_AI(On_NPC.orig_AI_007_TownEntities orig, NPC self)
		{
			orig(self);
			if (!Main.dayTime && !Main.eclipse && self.townNPC && self.ai[0] != 25f)
			{
                TryOpenNearbyDoor(self);
			}
		}
		
		private static void TryOpenNearbyDoor(NPC npc)
		{
			int npcTileX = (int)(npc.position.X + npc.width / 2) / 16;
			int npcTileY = (int)(npc.position.Y + npc.height - 16f) / 16;
		
			int searchRange = 15;
			int closestDoorX = -1;
			int closestDoorY = -1;
			float closestDistance = float.MaxValue;
						
			for (int x = npcTileX - searchRange; x <= npcTileX + searchRange; x++)
			{
				for (int y = npcTileY - searchRange; y <= npcTileY + searchRange; y++)
				{
					if (WorldGen.InWorld(x, y))
					{
						Tile tile = Main.tile[x, y];
						if (tile != null)
						{
							if (tile.TileType is TileID.ClosedDoor && tile.TileFrameX % 54 == 0)
							{
								float distance = Vector2.Distance(new Vector2(x, y), new Vector2(npcTileX, npcTileY));
						
								if (distance < closestDistance)
								{
									closestDistance = distance;
									closestDoorX = x;
									closestDoorY = y;
								}
							}
						}
					}
				}
			}
		
			if (closestDoorX >= 0 && closestDoorY >= 0 && Main.netMode != NetmodeID.MultiplayerClient)
			{
				Tile doorTile = Main.tile[closestDoorX, closestDoorY];
				if (doorTile.TileFrameX % 54 == 0)
				{
					float distanceToDoor = Vector2.Distance(new Vector2(closestDoorX, closestDoorY), new Vector2(npcTileX, npcTileY));
					if (distanceToDoor > 3f)
					{
						if (npc.ai[0] == 0f || npc.ai[0] == 1f)
						{
							int direction = closestDoorX > npcTileX ? 1 : -1;
							npc.direction = direction;
							npc.velocity.X = direction * 1f;
							npc.netUpdate = true;
						}
					}
					else
					{
						int direction = (npc.position.X + npc.width / 2) / 16f < closestDoorX ? 1 : -1;
						if (WorldGen.OpenDoor(closestDoorX, closestDoorY, direction))
						{
							NetMessage.SendData(MessageID.ToggleDoorState, -1, -1, null, 0, closestDoorX, closestDoorY, direction);
						}
						else if (WorldGen.OpenDoor(closestDoorX, closestDoorY, -direction))
						{
							NetMessage.SendData(MessageID.ToggleDoorState, -1, -1, null, 0, closestDoorX, closestDoorY, -direction);
						}
					}
				}
			}
		}

		public override void Unload()
		{
			
		}
	}
}
