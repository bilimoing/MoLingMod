﻿using Terraria;
using Terraria.ModLoader;
using WorstGame.Common.Configs;

namespace WorstGame.Common.GlobalTiles
{
    public class WorstGlobalTile : GlobalTile
    {
        public override bool CanDrop(int i, int j, int type)
        {
            if (TileConfigs.Instance.TileCanDrop)
            {
                if (Main.rand.NextFloat() < 0.1f)
                {
                    return false;
                }
            }
            return base.CanDrop(i, j, type);
        }
        
        public override void NearbyEffects(int i, int j, int type, bool closer)
        {
            if (TileConfigs.Instance.CampfireBurning)
            {
                if (type == Terraria.ID.TileID.Campfire)
                {
                    var campfireCenter = new Microsoft.Xna.Framework.Vector2(i * 16 + 8, j * 16 + 8);
                    for (int p = 0; p < Main.maxPlayers; p++)
                    {
                        Player player = Main.player[p];
                        if (player.active && !player.dead)
                        {
                            float distance = Microsoft.Xna.Framework.Vector2.Distance(player.Center, campfireCenter);
                            if (distance < 60f)
                            {
                                player.AddBuff(Terraria.ID.BuffID.OnFire, 90);
                            }
                        }
                    }
                }
            }
        }
    }
}
