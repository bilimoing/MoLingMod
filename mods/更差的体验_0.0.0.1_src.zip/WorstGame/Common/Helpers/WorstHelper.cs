﻿using System.Collections;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.Localization;
using WorstGame.Common.Configs;

namespace WorstGame.Common.Helpers
{
    public class WorstHelper
    {
        public static bool IsRecallItem(Item item)
        {
            int[] recallItems = [ItemID.MagicMirror, ItemID.IceMirror, ItemID.CellPhone, ItemID.RecallPotion, ItemID.Shellphone, ItemID.ShellphoneSpawn, ItemID.ShellphoneOcean, ItemID.ShellphoneHell, ItemID.PotionOfReturn,];
            return ((IList)recallItems).Contains(item.type);
        }


        public static int GetInventoryRows()
        {
            if (PlayerConfigs.Instance.InventoryRows)
            {
                var rows = 5;
                if (Main.hardMode)
                {
                    rows--;
                }
                if (NPC.downedMechBossAny)
                {
                    rows--;
                }
                if (NPC.downedPlantBoss)
                {
                    rows--;
                }
                if (NPC.downedAncientCultist)
                {
                    rows--;
                }
                return rows;
            }
            return 5;
        }
        
        public static int CountMinionsNearBed(int tileX, int tileY)
        {
            Player player = Main.LocalPlayer;
            int count = 0;
            Rectangle bedArea = new(tileX * 16 - 160, tileY * 16 - 160, 320, 320);
            for (int i = 0; i < Main.maxProjectiles; i++)
            {
                Projectile proj = Main.projectile[i];
                if (proj.active && proj.owner == player.whoAmI && (proj.minion || proj.sentry || proj.minionSlots > 0))
                {
                    if (bedArea.Intersects(proj.getRect()))
                    {
                        count++;
                    }
                }
            }
            return count;
        }
        
        public static int CountEntitiesNearBed1(int tileX, int tileY)
        {
            int count = 0;
            Rectangle bedArea = new(tileX * 16 - 160, tileY * 16 - 160, 320, 320);
            for (int i = 0; i < Main.maxNPCs; i++)
            {
                NPC npc = Main.npc[i];
                if (npc.active && !npc.friendly)
                {
                    if (bedArea.Intersects(npc.getRect()))
                    {
                        count++;
                    }
                }
            }
            return count;
        }
        
        public static int CountEntitiesNearBed(int tileX, int tileY)
        {
            Player player = Main.LocalPlayer;
            int count = 0;
            Rectangle bedArea = new(tileX * 16 - 160, tileY * 16 - 160, 320, 320);
            for (int i = 0; i < Main.maxPlayers; i++)
            {
                if (i != player.whoAmI && Main.player[i].active && !Main.player[i].dead)
                {
                    if (bedArea.Intersects(Main.player[i].getRect()))
                    {
                        count++;
                    }
                }
            }
            for (int i = 0; i < Main.maxNPCs; i++)
            {
                NPC npc = Main.npc[i];
                if (npc.active && npc.townNPC)
                {
                    if (bedArea.Intersects(npc.getRect()))
                    {
                        count++;
                    }
                }
            }
            return count;
        }
        
        public static bool HasLightSourcesNearBed(int tileX, int tileY)
        {
            for (int x = tileX - 3; x <= tileX + 3; x++)
            {
                for (int y = tileY - 3; y <= tileY + 3; y++)
                {
                    if (WorldGen.InWorld(x, y))
                    {
                        Tile tile = Main.tile[x, y];
                        if (tile != null && tile.HasTile)
                        {
                            if (IsLightSourceTile(tile.TileType))
                            {
                                return true;
                            }
                        }
                    }
                }
            }
            return false;
        }
        
        public static bool IsLightSourceTile(int tileType)
        {
            return tileType is TileID.Torches or TileID.Campfire or TileID.Candelabras or TileID.Lamps or TileID.Chandeliers or TileID.Candles or TileID.LavaMoss or TileID.WaterCandle or TileID.PeaceCandle or TileID.ShimmerflyinaBottle or TileID.FireflyinaBottle;
        }
        
        public static bool IsSummonProjectile(Projectile proj)
        {
            return proj.minion || proj.sentry || proj.minionSlots > 0;
        }
        
        public static void DespawnMinionsOnRecall()
        {
            Player player = Main.LocalPlayer;
            int despawnCount = 0;
            for (int i = 0; i < Main.maxProjectiles; i++)
            {
                Projectile proj = Main.projectile[i];
                if (proj.active && proj.owner == player.whoAmI && IsSummonProjectile(proj))
                {
                    proj.Kill();
                    despawnCount++;
                }
            }
            if (despawnCount > 0 && Main.netMode != NetmodeID.Server)
            {
                Main.NewText(Language.GetTextValue("Mods.WorstGame.NewText.Minion1") + $"{despawnCount}" + Language.GetTextValue("Mods.WorstGame.NewText.Minion2"), Color.LightBlue);
                Terraria.Audio.SoundEngine.PlaySound(SoundID.Item8 with { Pitch = -0.2f }, player.Center);
            }
        }
        
    }
}