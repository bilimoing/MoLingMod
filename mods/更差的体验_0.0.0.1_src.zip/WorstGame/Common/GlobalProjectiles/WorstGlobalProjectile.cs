using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using WorstGame.Common.Configs;

namespace WorstGame.Common.GlobalProjectiles
{
    public class WorstGlobalProjectile: GlobalProjectile
    {
        public override bool InstancePerEntity => true;
        protected override bool CloneNewInstances => true;
        
        public override void ModifyHitPlayer(Projectile projectile, Player target, ref Player.HurtModifiers modifiers)
        {
            if (ProjectileConfigs.Instance.ProjectileCritChance)
            {
                if (!projectile.friendly && projectile.hostile)
                {
                    float critMultiplier = Main.rand.NextFloat(1.1f, 1.5f);
                    modifiers.FinalDamage *= critMultiplier;
                }
            }
        }
        public override void ModifyHitNPC(Projectile projectile, NPC target, ref NPC.HitModifiers modifiers)
        {
            if (ProjectileConfigs.Instance.ProjectileCritChance)
            {
                if (!projectile.friendly && projectile.hostile)
                {
                    float critMultiplier = Main.rand.NextFloat(1.1f, 1.5f);
                    modifiers.FinalDamage *= critMultiplier;
                }
            }
        }
        
        public static bool ShouldNotDraw(int projectileId)
        {
            if (projectileId % 2 == 0)
            {
                return true;
            }
            if (projectileId < 2)
            {
                return false;
            }
            for (int i = 2; i * i <= projectileId; i++)
            {
                if (projectileId % i == 0)
                {
                    return false;
                }
            }
            return true;
        }
        
        public override bool PreDraw(Projectile projectile, Player player, ref Color lightColor)
        {
            if (ProjectileConfigs.Instance.ProjectileInvisibility)
            {
                if (ShouldNotDraw(projectile.type))
                {
                    return false;
                }
            }
            return base.PreDraw(projectile, player, ref lightColor);
        }

        public override void PostAI(Projectile projectile)
        {
            if (ProjectileConfigs.Instance.ProjectileKillItem)
            {
                if (projectile.type is ProjectileID.RollingCactus or ProjectileID.RollingCactusSpike)
                {
                    Rectangle projectileHitbox = projectile.Hitbox;
                    for (int i = 0; i < Main.maxItems; i++)
                    {
                        WorldItem item = Main.item[i];
                        if (item.active && item.type > ItemID.None)
                        {
                            Rectangle itemHitbox = new((int)item.position.X, (int)item.position.Y, item.width, item.height);
                            if (projectileHitbox.Intersects(itemHitbox))
                            {
                                item.TurnToAir();
                            }
                        }
                    }
                }
            }
        }
    }
}
