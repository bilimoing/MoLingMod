﻿using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.GameInput;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;
using WorstGame.Common.Configs;
using WorstGame.Common.Helpers;
using WorstGame.Common.Systems;

namespace WorstGame.Common.Players
{
    public class WorstPlayer : ModPlayer
    { 
        public int slot = 1;
        public LocalizedText DeathMessage;
        public const float SelfHarmChance = 0.05f;
        public bool usedRecallItem;
        
        public override bool CanUseItem(Item item)
        {
            if (ProjectileConfigs.Instance.MinionsDisappear)
            {
                if (WorstHelper.IsRecallItem(item))
                {
                    usedRecallItem = true;
                }
            }
            return base.CanUseItem(item);
        }
        
        public override void ProcessTriggers(TriggersSet triggersSet)
        {
            if (ItemConfigs.Instance.Itemmovement)
            {
                if (Player.whoAmI == Main.myPlayer)
                {
                    slot++;
                    if (slot > 4)
                    {
                        slot = 1;
                    }
                    for (int i = 0; i < 10; i++)
                    {
                        (Player.inventory[i], Player.inventory[slot * 10 + i]) = (Player.inventory[slot * 10 + i], Player.inventory[i]);
                        if (Main.netMode == NetmodeID.Server)
                        {
                            NetMessage.SendData(MessageID.SyncEquipment, -1, -1, null, Main.myPlayer, i, Main.LocalPlayer.inventory[i].prefix);
                            NetMessage.SendData(MessageID.SyncEquipment, -1, -1, null, Main.myPlayer, slot * 10 + i, Main.LocalPlayer.inventory[slot * 10 + i].prefix);
                        }
                    }
                    for (int i = 0; i < 10; i++)
                    {
                        int pos = Main.rand.Next(10, 50);
                        Item item = Player.inventory[pos];
                        Item item1 = Player.inventory[i];
                        Player.inventory[i] = item;
                        Player.inventory[pos] = item1;
                    }
                }
            }
            if (PlayerConfigs.Instance.SmartCursor)
            {
                if (Main.mouseRight)
                {
                    if (Main.rand.NextFloat() < 0.15f)
                    {
                        Player.controlSmart = true;
                    }
                }
            }
        }
        
        public override void PostSellItem(NPC vendor, Item[] shopInventory, Item item)
        {
            if (ItemConfigs.Instance.DynamicPricing)
            {
                if (!WorstSystem.OriginalItemValues.ContainsKey(item.type))
                {
                    Item tempItem = new();
                    tempItem.SetDefaults(item.type);
                    WorstSystem.OriginalItemValues[item.type] = tempItem.value;
                }
                if (item.value > 0)
                {
                    if (WorstSystem.ItemSalesCount.ContainsKey(item.type))
                    {
                        WorstSystem.ItemSalesCount[item.type] += item.stack;
                    }
                    else
                    {
                        WorstSystem.ItemSalesCount[item.type] = item.stack;
                    }
                    string itemName = Lang.GetItemNameValue(item.type);
                    int salesCount = WorstSystem.ItemSalesCount[item.type];
                    int priceReductionBatches = salesCount / 10;
                    float priceReduction = priceReductionBatches * 0.02f;
                    float priceReductionPercent = priceReduction * 100f;
                    if (salesCount % 10 == 0)
                    {
                        Main.NewText($"{itemName}" + Language.GetTextValue("Mods.WorstGame.NewText.Sell") + $"{priceReductionPercent:0}%", Color.Orange);
                    }
                }
            }
        }

        public override void PostUpdate()
        {
            if (ItemConfigs.Instance.SelfHarmOnWeaponUse)
            {
                if (Player.controlUseItem)
                {
                    float chance = Main.rand.NextFloat();
                    if (chance <= SelfHarmChance)
                    {
                        int damage = (int)(Player.HeldItem.damage * 0.3f);
                        Player.Hurt(PlayerDeathReason.ByCustomReason(DeathMessage.ToNetworkText(Player.name)), damage, 0);
                    }
                }
            }
            
            if (ProjectileConfigs.Instance.MinionsDisappear)
            {
                if (usedRecallItem)
                {
                    usedRecallItem = false;
                    WorstHelper.DespawnMinionsOnRecall();
                }
            }
            
            if (PlayerConfigs.Instance.HighLightSleep)
            {
                if (Player.sleeping.isSleeping)
                {
                    Point bedTilePos = Player.Bottom.ToTileCoordinates();
                    if (WorstHelper.HasLightSourcesNearBed(bedTilePos.X, bedTilePos.Y))
                    {
                        Player.sleeping.StopSleeping(Player);
                        if (Main.myPlayer == Player.whoAmI)
                        {
                            Main.NewText(Language.GetTextValue("Mods.WorstGame.NewText.Sleep"), Color.Orange);
                        }
                    }
                }
            }
            if (PlayerConfigs.Instance.MorePeopleDontSleep)
            {
                if (Player.sleeping.isSleeping)
                {
                    Point bedTilePos = Player.Bottom.ToTileCoordinates();
                    int entityCount = WorstHelper.CountEntitiesNearBed(bedTilePos.X, bedTilePos.Y);
                    if (entityCount >= 3)
                    {
                        Player.sleeping.StopSleeping(Player);
                        if (Main.myPlayer == Player.whoAmI)
                        {
                            Main.NewText(Language.GetTextValue("Mods.WorstGame.NewText.Sleep1"), Color.Orange);
                        }
                    }
                }
            }
            if (PlayerConfigs.Instance.ToManyMinionDontSleep)
            {
                if (Player.sleeping.isSleeping)
                {
                    Point bedTilePos = Player.Bottom.ToTileCoordinates();
                    int minionCount = WorstHelper.CountMinionsNearBed(bedTilePos.X, bedTilePos.Y);
                    if (minionCount >= 3)
                    {
                        Player.sleeping.StopSleeping(Player);
                        if (Main.myPlayer == Player.whoAmI)
                        {
                            Main.NewText(Language.GetTextValue("Mods.WorstGame.NewText.Sleep2"), Color.Orange);
                        }
                    }
                }
            }
            if (PlayerConfigs.Instance.ToManyMonstersDontSleep)
            {
                if (Player.sleeping.isSleeping)
                {
                    Point bedTilePos = Player.Bottom.ToTileCoordinates();
                    int entityCount = WorstHelper.CountEntitiesNearBed1(bedTilePos.X, bedTilePos.Y);
                    if (entityCount >= 3)
                    {
                        Player.sleeping.StopSleeping(Player);
                        if (Main.myPlayer == Player.whoAmI)
                        {
                            Main.NewText(Language.GetTextValue("Mods.WorstGame.NewText.Sleep3"), Color.Orange);
                        }
                    }
                }
            }
        }
        
        public override void PostUpdateBuffs()
        {
            if (MultiplayerModeConfigs.Instance.SharedBuff)
            {
                for (int i = 0; i < Main.CurrentFrameFlags.ActivePlayersCount; i++)
                {
                    for (int j = 0; j < BuffLoader.BuffCount; j++)
                    {
                        if (Player.HasBuff(j) && !Main.player[i].HasBuff(j))
                        {
                            Main.player[i].AddBuff(j, 300, true);
                        }
                    }
                }
            }
        }
        
        public override void ResetEffects()
        {
            if (PlayerConfigs.Instance.Defensehalved)
            {
                Player.statDefense /= 2;
            }
            if (PlayerConfigs.Instance.HalvesMPHP)
            {
                Player.statManaMax2 /= 2;
                Player.statLifeMax2 /= 2;
            }
        }
        
        public override void CatchFish(FishingAttempt attempt, ref int itemDrop, ref int npcSpawn, ref AdvancedPopupRequest sonar, ref Vector2 sonarPosition)
        {
            if (PlayerConfigs.Instance.QuestFishDisappeared)
            {
                if (itemDrop == Main.anglerQuestItemNetIDs[Main.anglerQuest])
                {
                    if (Main.rand.NextFloat() < 0.5f)
                    {
                        itemDrop = ItemID.None;
                        Main.AnglerQuestSwap();
                        Main.NewText(Language.GetTextValue("Mods.WorstGame.NewText.Fish"), 255, 100, 100);
                    }
                }
            }
        }
        
        public override void OnRespawn()
        {
            if (PlayerConfigs.Instance.InitialHP)
            {
                Player.statLife = 1;
            }
        }
        
        public override void PreUpdate()
        {
            if (PlayerConfigs.Instance.Breathingtime)
            {
                Player.breathMax = 30;
            }
        }
        
        public override void Kill(double damage, int hitDirection, bool pvp, PlayerDeathReason damageSource)
        {
            if (PlayerConfigs.Instance.Respawntimedoubled)
            {
                Player.respawnTimer = 3600;
            }
            if (MultiplayerModeConfigs.Instance.DeathLink)
            {
                if (Main.netMode != NetmodeID.Server)
                {
                    foreach (var target in Main.player)
                    {
                        if (target.active && !target.dead)
                        {
                            if (target.whoAmI != Player.whoAmI)
                            {
                                if (target.whoAmI == Main.myPlayer)
                                {
                                    target.KillMe(PlayerDeathReason.ByCustomReason(DeathMessage.ToNetworkText(Player.name)), 228, 0);
                                }
                            }
                        }
                    }
                }
            }
        }
        
        public override void PostUpdateEquips()
        {
            if (PlayerConfigs.Instance.Wingflighttimehalved)
            {
                if (Player.wings > 0)
                {
                    Player.wingTimeMax /= 2;
                }
            }
        }
    }
}