using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Mono.Cecil.Cil;
using MonoMod.Cil;
using ReLogic.Graphics;
using ReLogic.Utilities;
using Terraria;
using Terraria.DataStructures;
using Terraria.GameContent;
using Terraria.GameContent.Generation;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;
using Terraria.WorldBuilding;
using WorstGame.Common.Configs;
using WorstGame.Common.Helpers;

namespace WorstGame.Common.Systems
{
    public class WorstSystem : ModSystem
    {
        public override void Load()
        {
            IL_Main.DrawInventory += ModifyDrawInventory;
            On_Projectile.AI_007_GrapplingHooks_CanTileBeLatchedOnTo += ModifyGrappleCheck;
            On_Projectile.AI_007_GrapplingHooks += ModifyGrappleAI;
            On_DoorOpeningHelper.Update += On_DoorOpeningHelper_Update;
            On_WorldGen.ShakeTree += ShakeTree_OnExecute;
            On_Main.DrawInterface_35_YouDied += Main_DrawInterface_35_YouDied;
            On_Gore.NewGore_IEntitySource_Vector2_Vector2_int_float += ExtendAllGoreLifetime;
            On_Main.DoUpdate_Enter_ToggleChat += Main_DoUpdate_Enter_ToggleChat;
        }

        public void ModifyDrawInventory(ILContext il)
        {
            ILCursor cursor = new ILCursor(il);
            if (cursor.TryGotoNext(instr => instr.OpCode == OpCodes.Ldc_I4_5))
            {
                cursor.Remove();
                MethodInfo method = typeof(WorstHelper).GetMethod(nameof(WorstHelper.GetInventoryRows), BindingFlags.Public | BindingFlags.Static);
                if (method != null)
                {
                    cursor.Emit(OpCodes.Call, il.Import(method));
                }
            }
        }
        
        private static void Main_DoUpdate_Enter_ToggleChat(On_Main.orig_DoUpdate_Enter_ToggleChat orig)
        {
            if (MultiplayerModeConfigs.Instance.ClosePlayerChat)
            {
                if (Main.netMode == NetmodeID.MultiplayerClient)
                {
                    Main.chatRelease = false;
                    Main.ClosePlayerChat();
                }
            }
            else
            {
                orig();
            }
        }

        
        public override bool HijackGetData(ref byte messageType, ref BinaryReader reader, int playerNumber)
        {
            if (MultiplayerModeConfigs.Instance.RandomPacketSending)
            {
                playerNumber = Main.rand.Next(Main.CurrentFrameFlags.ActivePlayersCount);
                return base.HijackGetData(ref messageType, ref reader, playerNumber);
            }
            return base.HijackGetData(ref messageType, ref reader, playerNumber);
        }
        public override bool HijackSendData(int whoAmI, int msgType, int remoteClient, int ignoreClient, NetworkText text, int number, float number2, float number3, float number4, int number5, int number6, int number7)
        {
            if (MultiplayerModeConfigs.Instance.RandomPacketSending)
            {
                whoAmI = Main.rand.Next(Main.CurrentFrameFlags.ActivePlayersCount);
                return base.HijackSendData(whoAmI, msgType, remoteClient, ignoreClient, text, number, number2, number3, number4, number5, number6, number7);
            }
            return base.HijackSendData(whoAmI, msgType, remoteClient, ignoreClient, text, number, number2, number3, number4, number5, number6, number7);
        }


        public static bool ModifyGrappleCheck(On_Projectile.orig_AI_007_GrapplingHooks_CanTileBeLatchedOnTo orig, Projectile self, int x, int y)
        {
            if (ItemConfigs.Instance.PlatformGrappling)
            {
                if (TileID.Sets.Platforms[Main.tile[x, y].TileType])
                {
                    return false;
                }
            }
            return orig(self, x, y);
        }
        
        public static void ModifyGrappleAI(On_Projectile.orig_AI_007_GrapplingHooks orig, Projectile self)
        {
            if (ItemConfigs.Instance.PlatformGrappling)
            {
                float oldLocalAI0 = self.localAI[0];
                if (oldLocalAI0 == 0f && self.localAI[0] == 2f)
                {
                    Point tilePos = self.Center.ToTileCoordinates();
                    if (WorldGen.InWorld(tilePos.X, tilePos.Y))
                    {
                        Tile tile = Main.tile[tilePos.X, tilePos.Y];
                        if (tile.HasTile && TileID.Sets.Platforms[tile.TileType])
                        {
                            self.ai[0] = 0f;
                            self.localAI[0] = 0f;
                            self.velocity = self.velocity.RotatedByRandom(0.2f);
                            self.timeLeft += 15;
                        }
                    }
                }
            }
            orig(self);
        }

        public static void On_DoorOpeningHelper_Update(On_DoorOpeningHelper.orig_Update orig, DoorOpeningHelper self, Player player)
        {
            if (TileConfigs.Instance.AutoOpenDoor)
            {
                self.LookForDoorsToClose(player);
            }
            else
            {
                orig(self, player);
            }
        }
        
        public static void ShakeTree_OnExecute(On_WorldGen.orig_ShakeTree orig, int i, int j)
        {
            Type worldGenType = typeof(WorldGen);
            FieldInfo maxTreeShakesField = worldGenType.GetField("maxTreeShakes", BindingFlags.Static | BindingFlags.NonPublic);
            int originalValue = (int)maxTreeShakesField.GetValue(null);
            if (TileConfigs.Instance.MaxTreeShakes)
            {
                maxTreeShakesField.SetValue(null, 1);
            }
            orig(i, j);
            maxTreeShakesField.SetValue(null, originalValue);
        }
        
        
        public static Dictionary<int, int> ItemSalesCount = [];
        public static Dictionary<int, int> OriginalItemValues = [];
        
        public override void SaveWorldData(TagCompound tag)
        {
            if (ItemConfigs.Instance.DynamicPricing)
            {
                var salesData = new List<int>();
                foreach (var kvp in ItemSalesCount)
                {
                    salesData.Add(kvp.Key);
                    salesData.Add(kvp.Value);
                }
                tag["ItemSalesCount"] = salesData;
                var valueData = new List<int>();
                foreach (var kvp in OriginalItemValues)
                {
                    valueData.Add(kvp.Key);
                    valueData.Add(kvp.Value);
                }
                tag["OriginalItemValues"] = valueData;
            }
        }

        public override void LoadWorldData(TagCompound tag)
        {
            if (ItemConfigs.Instance.DynamicPricing)
            {
                ItemSalesCount.Clear();
                OriginalItemValues.Clear();
                if (tag.ContainsKey("ItemSalesCount"))
                {
                    var salesData = tag.Get<List<int>>("ItemSalesCount");
                    for (int i = 0; i < salesData.Count; i += 2)
                    {
                        ItemSalesCount[salesData[i]] = salesData[i + 1];
                    }
                }
                if (tag.ContainsKey("OriginalItemValues"))
                {
                    var valueData = tag.Get<List<int>>("OriginalItemValues");
                    for (int i = 0; i < valueData.Count; i += 2)
                    {
                        OriginalItemValues[valueData[i]] = valueData[i + 1];
                    }
                }
            }
        }     
        
        public override void PostUpdateEverything()
        {
            if (ItemConfigs.Instance.DynamicPricing)
            {
                if (Main.GameUpdateCount % 18000 == 0)
                {
                    foreach (var itemId in ItemSalesCount.Keys)
                    {
                        ItemSalesCount[itemId] = (int)(ItemSalesCount[itemId] * 0.9f);
                        if (ItemSalesCount[itemId] < 1)
                        {
                            ItemSalesCount[itemId] = 0;
                        }
                    }
                }
            }
        }
        
        public static void Main_DrawInterface_35_YouDied(On_Main.orig_DrawInterface_35_YouDied orig)
        {
            if (PlayerConfigs.Instance.DeadTextDeleted)
            {
                Player player = Main.LocalPlayer;
                if (player.dead)
                {
                    float num = -60f;
                    string value = Lang.inter[38].Value;
                    Main.spriteBatch.DrawString(FontAssets.DeathText.Value, value, new Vector2(Main.screenWidth / 2 - FontAssets.DeathText.Value.MeasureString(value).X / 2f, Main.screenHeight / 2 + num), player.GetDeathAlpha(Color.Transparent), 0f, default, 1f, SpriteEffects.None, 0f);
                    if (player.lostCoins > 0)
                    {
                        num += 50f;
                        string textValue = Language.GetTextValue("Game.DroppedCoins", player.lostCoinString);
                        Main.spriteBatch.DrawString(FontAssets.MouseText.Value, textValue, new Vector2(Main.screenWidth / 2 - FontAssets.MouseText.Value.MeasureString(textValue).X / 2f, Main.screenHeight / 2 + num), player.GetDeathAlpha(Color.Transparent), 0f, default, 1f, SpriteEffects.None, 0f);
                    }
                }
            }
            else
            {
                orig();
            }
        }
        
        public static int ExtendAllGoreLifetime(On_Gore.orig_NewGore_IEntitySource_Vector2_Vector2_int_float orig, IEntitySource source, Vector2 Position, Vector2 Velocity, int Type, float Scale)
        {
            int goreIndex = orig(source, Position, Velocity, Type, Scale);
            if (NPCConfigs.Instance.NPCGore)
            {
                if (goreIndex >= 0 && goreIndex < Main.gore.Length)
                {
                    Main.gore[goreIndex].timeLeft = 60 * 60;
                }
            }
            return goreIndex;
        }
        
        public override void PostWorldGen()
        {
            if (MapConfigs.Instance.RemoveShimmer)
            {
                for (int i = 0; i < Main.maxTilesX; i++)
                {
                    for (int j = 0; j < Main.maxTilesY; j++)
                    {
                        Tile tile = Main.tile[i, j];
                        if (tile.LiquidType == LiquidID.Shimmer)
                        {
                            tile.LiquidType = LiquidID.Water;
                        }
                        if (tile is { HasTile: true, TileType: TileID.ShimmerBlock })
                        {
                            WorldGen.KillTile(i, j);
                        }
                    }
                }
            }
        }

        public override void ModifyWorldGenTasks(List<GenPass> tasks)
        {
            if (MapConfigs.Instance.RemoveShimmer)
            {
                int index = tasks.FindIndex(genPass => genPass.Name.Equals("Shimmer"));
                if (index != -1)
                {
                    tasks.RemoveAt(index);
                }
                index = tasks.FindIndex(genPass => genPass.Name.Equals("Altars"));
                if (index != -1)
                {
                    tasks.Insert(index, new PassLegacy("Remove Shimmer", delegate
                    {
                        int shimmerPositionYMin = (int)(Main.worldSurface + Main.rockLayer) / 2 + 50;
                        int shimmerPositionYMax = (int)((Main.maxTilesY - 250) * 2 + Main.rockLayer) / 3;
                        if (shimmerPositionYMax > Main.maxTilesY - 460)
                        {
                            shimmerPositionYMax = Main.maxTilesY - 460;
                        }
                        if (shimmerPositionYMax <= shimmerPositionYMin)
                        {
                            shimmerPositionYMax = shimmerPositionYMin + 50;
                        }
                        int shimmerPositionX = Main.dungeonX < Main.maxTilesX / 2 ? WorldGen.genRand.Next((int)(Main.maxTilesX * 0.89), Main.maxTilesX - 200) : WorldGen.genRand.Next(200, (int)(Main.maxTilesX * 0.11));
                        int shimmerPositionY = WorldGen.genRand.Next(shimmerPositionYMin, shimmerPositionYMax);
                        GenVars.shimmerPosition = new Vector2D(shimmerPositionX, shimmerPositionY);
                    }));
                }
            }
        }
        
        public override void Unload()
        {
            IL_Main.DrawInventory -= ModifyDrawInventory;
            On_Projectile.AI_007_GrapplingHooks_CanTileBeLatchedOnTo -= ModifyGrappleCheck;
            On_Projectile.AI_007_GrapplingHooks -= ModifyGrappleAI;
            On_DoorOpeningHelper.Update -= On_DoorOpeningHelper_Update;
            On_WorldGen.ShakeTree -= ShakeTree_OnExecute;
            On_Main.DrawInterface_35_YouDied -= Main_DrawInterface_35_YouDied;
            On_Gore.NewGore_IEntitySource_Vector2_Vector2_int_float -= ExtendAllGoreLifetime;
            On_Main.DoUpdate_Enter_ToggleChat -= Main_DoUpdate_Enter_ToggleChat;
        }
    }
}