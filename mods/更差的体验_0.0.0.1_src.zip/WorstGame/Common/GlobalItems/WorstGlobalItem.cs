﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.Utilities;
using WorstGame.Common.Configs;
using WorstGame.Common.Systems;
using WorstGame.Content.Prefixes;

namespace WorstGame.Common.GlobalItems
{
    public class WorstGlobalItem : GlobalItem
    {
        public override bool InstancePerEntity => true;
        protected override bool CloneNewInstances => true;

        public const float MinScale = 0.5f;
        public const float MaxScale = 1.8f;

        public override void SetStaticDefaults()
        {
            if (ItemConfigs.Instance.DynamicPricing)
            {
                for (int i = 1; i < ItemLoader.ItemCount; i++)
                {
                    if (!WorstSystem.OriginalItemValues.ContainsKey(i))
                    {
                        Item tempItem = new();
                        tempItem.SetDefaults(i);
                        if (tempItem.value > 0)
                        {
                            WorstSystem.OriginalItemValues[i] = tempItem.value;
                        }
                    }
                }
            }
        }
        
        public override int ChoosePrefix(Item item, UnifiedRandom rand)
        {
            if (ItemConfigs.Instance.WorstPrefix)
            {
                if (item.DamageType == DamageClass.Melee || item.DamageType == DamageClass.MeleeNoSpeed)
                {
                    return ModContent.PrefixType<Dreadful>();
                }
                if (item.DamageType == DamageClass.Ranged)
                {
                    return ModContent.PrefixType<Broken>();
                }
                if (item.DamageType == DamageClass.Magic)
                {
                    return ModContent.PrefixType<Futile>();
                }
            }
            return base.ChoosePrefix(item, rand);
        }        
        
        public override void UpdateInventory(Item item, Player player)
        {
            if (ItemConfigs.Instance.DynamicPricing)
            {
                if (item.value > 0 && WorstSystem.ItemSalesCount.TryGetValue(item.type, out int salesCount) && WorstSystem.OriginalItemValues.TryGetValue(item.type, out int originalValue))
                {
                    float priceReduction = salesCount / 10 * 0.02f;
                    float priceMultiplier = Math.Max(1f - priceReduction, 0.5f);
                    item.value = (int)(originalValue * priceMultiplier);
                }
            }
        }
        
        public override bool PreDrawTooltipLine(Item item, DrawableTooltipLine line, ref int yOffset)
        {
            if (ItemConfigs.Instance.ChaosTooltip)
            {
                Vector2 position = new(line.X, line.Y);
                float maxHeight = 0f;
                foreach (var t in line.Text)
                {
                    line.BaseScale = new Vector2(Main.rand.NextFloat(MinScale, MaxScale), Main.rand.NextFloat(MinScale, MaxScale));
                    string charStr = t.ToString();
                    Vector2 charSize = line.Font.MeasureString(charStr) * line.BaseScale;
                    Utils.DrawBorderStringFourWay(Main.spriteBatch, line.Font, charStr, position.X + charSize.X / 2, position.Y + charSize.Y / 2, line.Color, Color.Black, new Vector2(0.3f));
                    position.X += charSize.X;
                    maxHeight = Math.Max(maxHeight, charSize.Y);
                }
                return false;
            }
            return base.PreDrawTooltipLine(item, line, ref yOffset);
        }        

        public override void OnCreated(Item item, ItemCreationContext context)
        {
            if (ItemConfigs.Instance.DynamicPricing)
            {
                if (item.value > 0 && WorstSystem.ItemSalesCount.TryGetValue(item.type, out int salesCount) && WorstSystem.OriginalItemValues.TryGetValue(item.type, out int originalValue))
                {
                    float priceReduction = salesCount / 10 * 0.02f;
                    float priceMultiplier = Math.Max(1f - priceReduction, 0.5f);
                    item.value = (int)(originalValue * priceMultiplier);
                }
            }
        }


        public override void SetDefaults(Item item)
        {
            if (ItemConfigs.Instance.AutoReuse)
            {
                item.autoReuse = false;
            }
            if (ItemConfigs.Instance.BaitPowerHalved)
            {
                item.bait /= 2;
            }
            if (ItemConfigs.Instance.CritChance)
            {
                item.crit = -114514;
            }
            if (ItemConfigs.Instance.DamageDefault)
            {
                item.DamageType = DamageClass.Default;
            }
            if (ItemConfigs.Instance.DoubleMP)
            {
                item.mana *= 2;
            }
            if (ItemConfigs.Instance.FishingPowerHalved)
            {
                item.fishingPole /= 2;
            }
            if (ItemConfigs.Instance.MaxStack)
            {
                item.maxStack = 1;
            }
            if (ItemConfigs.Instance.RandomResearch)
            {
                if (item.ResearchUnlockCount > 0 && item.type < ItemID.Count && !Main.LocalPlayer.HasItem(item.type))
                {
                    int multiplier = Main.rand.Next(1, 201);
                    item.ResearchUnlockCount *= multiplier;
                }
            }
        }
    }
}