using System;
using System.Reflection;
using MonoMod.RuntimeDetour;
using Terraria;
using Terraria.ModLoader;
using WorstGame.Common.Configs;

namespace WorstGame
{
	public class WorstGame : Mod
	{
		public Hook _dataPlayerHook;
		public Hook _modItemGridHook;
		
        public override void Load()
        {
            if (ModLoader.TryGetMod("ImproveGame", out Mod improveGame))
            {
                Type dataPlayerType = improveGame.Code.GetType("ImproveGame.Common.ModPlayers.DataPlayer");
                if (dataPlayerType != null)
                {
                    MethodInfo initializeMethod = dataPlayerType.GetMethod("Initialize", BindingFlags.Instance | BindingFlags.Public);
                    if (initializeMethod != null)
                    {
                        _dataPlayerHook = new Hook(initializeMethod, On_DataPlayer_Initialize);
                        _dataPlayerHook.Apply();
                    }
                }
                Type modItemGridType = improveGame.Code.GetType("ImproveGame.UIFramework.UIElements.ModItemGrid");
                if (modItemGridType != null)
                {
                    ConstructorInfo constructor = modItemGridType.GetConstructor(Type.EmptyTypes);
                    if (constructor != null)
                    {
                        _modItemGridHook = new Hook(constructor, On_ModItemGrid_Constructor);
                        _modItemGridHook.Apply();
                    }
                }
            }
        }
        
        public override void Unload()
        {
            _dataPlayerHook?.Dispose();
            _modItemGridHook?.Dispose();
            _dataPlayerHook = null;
            _modItemGridHook = null;
        }
        
        public static void On_DataPlayer_Initialize(Action<object> orig, object self)
        {
            orig(self);
            if (LinkConfigs.Instance.BigBag)
            {
                int capacity = 10;
                FieldInfo superVaultField = self.GetType().GetField("SuperVault", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                superVaultField?.SetValue(self, new Item[capacity]);

            }
        }
        
        public static void On_ModItemGrid_Constructor(Action<object> orig, object self)
        {
            orig(self);
            if (LinkConfigs.Instance.BigBag)
            {
                FieldInfo itemListField = self.GetType().GetField("ItemList", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if (itemListField != null)
                {
                    object itemList = itemListField.GetValue(self);
                    if (itemList != null)
                    {
                        MethodInfo modifyMethod = itemList.GetType().GetMethod("ModifyHVCount", BindingFlags.Instance | BindingFlags.Public);
                        if (modifyMethod != null)
                        {
                            object[] args = [10, 1, 52, 10f];
                            modifyMethod.Invoke(itemList, args);
                        }
                    }
                }
            }
        }
	}
}
