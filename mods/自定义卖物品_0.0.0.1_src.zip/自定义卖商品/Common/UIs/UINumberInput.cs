using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.Audio;
using Terraria.GameContent.UI.Elements;
using Terraria.GameInput;
using Terraria.ID;
using Terraria.UI;

namespace 自定义卖商品.Common.UIs
{
    public class UINumberInput : UIPanel
    {
        public readonly string hintText;
        public string currentText;
        public bool isFocused;
        public readonly Action<int> onValueChanged;
        public Action onFocusChanged;
        public UINumberInput(string hint, int initialValue, Action<int> onChanged)
        {
            hintText = hint;
            currentText = initialValue == -1 ? "" : initialValue.ToString();
            onValueChanged = onChanged;
            SetPadding(5);
            BorderColor = Color.Gray;
            BackgroundColor = new Color(20, 20, 30);
        }
        public override void LeftClick(UIMouseEvent evt)
        {
            base.LeftClick(evt);
            if (!isFocused)
            {
                isFocused = true;
                BorderColor = Color.Yellow;
                Main.clrInput();
                PlayerInput.WritingText = true;
                onFocusChanged?.Invoke();
            }
        }
        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
            if (IsMouseHovering)
            {
                Main.LocalPlayer.mouseInterface = true;
            }
            if (isFocused)
            {
                if (Main.mouseLeft && !IsMouseHovering)
                {
                    LoseFocus();
                    return;
                }
            }
        }
        public void LoseFocus()
        {
            isFocused = false;
            BorderColor = Color.Gray;
            Main.blockInput = false;
            PlayerInput.WritingText = false;
            onFocusChanged?.Invoke();
            SubmitValue();
            SoundEngine.PlaySound(SoundID.MenuTick);
        }
        public void SubmitValue()
        {
            if (string.IsNullOrEmpty(currentText))
            {
                onValueChanged?.Invoke(-1);
            }
            else if (int.TryParse(currentText, out int result))
            {
                onValueChanged?.Invoke(result);
            }
            else
            {
                onValueChanged?.Invoke(-1);
                currentText = "";
            }
        }
        protected override void DrawSelf(SpriteBatch spriteBatch)
        {
            base.DrawSelf(spriteBatch);
            string display = string.IsNullOrEmpty(currentText) ? (isFocused ? "" : hintText) : currentText;
            Color color = string.IsNullOrEmpty(currentText) ? Color.Gray : Color.White;
            if (isFocused && Main.GameUpdateCount % 60 < 30) display += "|";
            Vector2 drawPos = GetDimensions().Position() + new Vector2(6, 4);
            Utils.DrawBorderString(spriteBatch, display, drawPos, color, 0.8f);
        }
    }
}
