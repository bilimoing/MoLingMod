﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using ReLogic.Content;
using ReLogic.Graphics;
using System;
using Terraria;
using Terraria.GameContent;
using Terraria.UI;
namespace 自定义卖商品.Common.UIs
{
    public class UIItemIcon(ShopCustomizerUI owner, int itemType) : UIElement
    {
        public ShopCustomizerUI _owner = owner;
        public int ItemType = itemType;
        public const int padding = 2;
        public void SetItem(int itemType)
        {
            ItemType = itemType;
        }
        public override void Draw(SpriteBatch spriteBatch)
        {
            base.Draw(spriteBatch);
            CalculatedStyle dims = GetDimensions();
            float w = dims.Width;
            float h = dims.Height;
            if (ItemType <= 0)
            {
                DrawItemNameFallback(spriteBatch, "无效物品", dims);
                return;
            }
            Texture2D tex = null;
            Rectangle src = Rectangle.Empty;
            bool textureAndFrameReady = false;
            bool exceptionOccurred = false;
            try
            {
                Main.instance.LoadItem(ItemType);
                Asset<Texture2D> asset = TextureAssets.Item[ItemType];
                if (asset != null && asset.Value != null)
                {
                    tex = asset.Value;
                    if (tex != null)
                    {
                        if (ItemType < Main.itemAnimations.Length && Main.itemAnimations[ItemType] != null)
                        {
                            try
                            {
                                src = Main.itemAnimations[ItemType].GetFrame(tex);
                            }
                            catch
                            {
                                src = tex.Frame();
                            }
                        }
                        else
                        {
                            src = tex.Frame();
                        }
                        if (tex != null && !src.IsEmpty)
                        {
                            textureAndFrameReady = true;
                        }
                    }
                }
            }
            catch (Exception)
            {
                exceptionOccurred = true;
            }
            if (textureAndFrameReady)
            {
                Vector2 pos = dims.Position();
                float availW = Math.Max(1f, w - padding * 2);
                float availH = Math.Max(1f, h - padding * 2);
                float scale = 1f;
                if (src.Width > 0 && src.Height > 0)
                {
                    scale = Math.Min(availW / src.Width, availH / src.Height);
                }
                scale = Math.Min(scale, 1f);
                Vector2 origin = new(src.Width / 2f, src.Height / 2f);
                Vector2 drawPos = pos + new Vector2(w / 2f, h / 2f);
                spriteBatch.Draw(tex, drawPos, src, Color.White, 0f, origin, scale, SpriteEffects.None, 0f);
            }
            else if (exceptionOccurred)
            {
                string itemName = Lang.GetItemName(ItemType).Value;
                DrawItemNameFallback(spriteBatch, itemName, dims);
            }
        }
        public static void DrawItemNameFallback(SpriteBatch spriteBatch, string name, CalculatedStyle dims)
        {
            if (string.IsNullOrEmpty(name)) return;
            Vector2 drawCenter = dims.Center();
            DynamicSpriteFont font = FontAssets.MouseText.Value;
            Vector2 stringSize = font.MeasureString(name);
            float scale = 0.6f;
            float maxTextWidth = dims.Width - padding * 2;
            if (stringSize.X * scale > maxTextWidth)
            {
                scale = maxTextWidth / stringSize.X;
                if (scale < 0.3f) scale = 0.3f;
            }
            Vector2 textOrigin = stringSize * 0.5f;
            Utils.DrawBorderString(spriteBatch, name, drawCenter, Color.White, scale, textOrigin.X, textOrigin.Y);
        }
    }
}