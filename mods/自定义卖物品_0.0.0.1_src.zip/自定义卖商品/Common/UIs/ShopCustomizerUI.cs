using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using ReLogic.Content;
using System;
using System.Collections.Generic;
using System.Linq;
using Terraria;
using Terraria.Audio;
using Terraria.GameContent.UI.Elements;
using Terraria.GameInput;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;
using Terraria.UI;
using 自定义卖商品.Common.GlobalNPCs;
using 自定义卖商品.Common.Helpers;
using 自定义卖商品.Common.Systems;
namespace 自定义卖商品.Common.UIs
{
    public class ShopCustomizerUI(ShopCustomizerSystem sys) : UIState
    {
        public string currentSortMode = "ID";
        public readonly ShopCustomizerSystem system = sys;
        public UIPanel mainPanel;
        public UIPanel shopSelectionPanel;
        public UIList shopList;
        public UIScrollbar shopScrollbar;
        public UIPanel conditionalItemsManagementPanel;
        public UIList conditionalItemsManagementList;
        public UIScrollbar conditionalItemsManagementScrollbar;
        public UIList npcCategoryList;
        public UIList npcList;
        public UIScrollbar npcScrollbar;
        public string currentNpcModFilter = "Terraria";
        public readonly Dictionary<string, List<int>> npcDataByMod = [];
        public int currentSelectedNPC = -1;
        public string currentSelectedShop = "Shop";
        public UIPanel searchBoxPanel;
        public UISearchBar searchBar;
        private UINumberInput activeNumberInput;
        public UIList itemList;
        public UIScrollbar itemScrollbar;
        public UIText pageText;
        public UIPanel prevPageBtn;
        public UIPanel nextPageBtn;
        public string currentSearchText = "";
        public int currentPage = 0;
        public const int ITEMS_PER_PAGE = 200;
        public UIList filterList;
        public UIScrollbar filterScrollbar;
        public string currentFilterKey = (string)Language.GetText("Mods.自定义卖商品.UI.30");
        public string currentCategory = "";
        public UIList selectedItemsList;
        public UIScrollbar selectedItemsScrollbar;
        public UINPCIcon npcHeadImage;
        public UIText selectedNpcName;
        public UIPanel conditionBrowserPanel;
        public UIList conditionBrowserList;
        public UIScrollbar conditionBrowserScrollbar;
        public bool isConditionBrowserOpen = false;
        public int currentTargetItemIndex = -1;
        public int currentTargetConditionSlot = -1;
        public UIPanel currencyBrowserPanel;
        public UIList currencyBrowserList;
        public UIScrollbar currencyBrowserScrollbar;
        public bool isCurrencyBrowserOpen = false;
        public int currentTargetCurrencyItemIndex = -1;
        public UIPanel npcDefaultShopPanel;
        public UIList npcDefaultShopItemList;
        public UIScrollbar npcDefaultShopScrollbar;
        public static readonly int[] ManualNPCList =
        [
           NPCID.Guide, NPCID.Merchant, NPCID.Nurse, NPCID.Dryad, NPCID.ArmsDealer,
            NPCID.Demolitionist, NPCID.Clothier, NPCID.GoblinTinkerer, NPCID.Wizard,
            NPCID.Mechanic, NPCID.SantaClaus, NPCID.Truffle, NPCID.Steampunker,
            NPCID.DyeTrader, NPCID.PartyGirl, NPCID.Cyborg, NPCID.Painter,
            NPCID.WitchDoctor, NPCID.Pirate, NPCID.Stylist, NPCID.TravellingMerchant,
            NPCID.Angler, NPCID.TaxCollector, NPCID.SkeletonMerchant, NPCID.BestiaryGirl,
            NPCID.Golfer, NPCID.DD2Bartender, NPCID.Princess,
        ];
        public static Dictionary<string, List<string>> CategoryStructure
        {
            get
            {
                var weaponList = new List<string>
                {
                    "Mods.自定义卖商品.UI.34",
                    "Mods.自定义卖商品.UI.35",
                    "Mods.自定义卖商品.UI.36",
                    "Mods.自定义卖商品.UI.37",
                    "Mods.自定义卖商品.UI.38",
                    "Mods.自定义卖商品.UI.39",
                };
                if (ModLoader.HasMod("CalamityMod"))
                {
                    weaponList.Add("Mods.自定义卖商品.UI.Calamity_Rogue");
                }
                return new Dictionary<string, List<string>>
                {
                    { "Mods.自定义卖商品.UI.70", weaponList },
                    { "Mods.自定义卖商品.UI.71", new List<string> { "Mods.自定义卖商品.UI.40", "Mods.自定义卖商品.UI.41", "Mods.自定义卖商品.UI.42", "Mods.自定义卖商品.UI.43", "Mods.自定义卖商品.UI.44" } },
                    { "Mods.自定义卖商品.UI.72", new List<string> { "Mods.自定义卖商品.UI.45", "Mods.自定义卖商品.UI.46", "Mods.自定义卖商品.UI.47", "Mods.自定义卖商品.UI.48" } },
                    { "Mods.自定义卖商品.UI.73", new List<string> { "Mods.自定义卖商品.UI.64", "Mods.自定义卖商品.UI.65" } },
                    { "Mods.自定义卖商品.UI.74", new List<string> { "Mods.自定义卖商品.UI.58", "Mods.自定义卖商品.UI.59", "Mods.自定义卖商品.UI.60", "Mods.自定义卖商品.UI.61" } },
                    { "Mods.自定义卖商品.UI.75", new List<string> { "Mods.自定义卖商品.UI.54", "Mods.自定义卖商品.UI.55" } },
                    { "Mods.自定义卖商品.UI.76", new List<string> { "Mods.自定义卖商品.UI.56", "Mods.自定义卖商品.UI.57" } },
                    { "Mods.自定义卖商品.UI.77", new List<string> { "Mods.自定义卖商品.UI.51", "Mods.自定义卖商品.UI.53" } },
                    { "Mods.自定义卖商品.UI.78", new List<string> { "Mods.自定义卖商品.UI.62", "Mods.自定义卖商品.UI.50" } },
                };
            }
        }
        public static Dictionary<string, Func<Item, bool>> GetFilterDefinitions()
        {
            DamageClass rogueClass = null;
            if (ModLoader.TryGetMod("CalamityMod", out Mod calamityMod))
            {
                calamityMod.TryFind("RogueDamageClass", out rogueClass);
            }
            var definitions = new Dictionary<string, Func<Item, bool>>
            {
                { "Mods.自定义卖商品.UI.30", item => true },
                { "Mods.自定义卖商品.UI.33", item => Main.projHook[item.shoot] },
                { "Mods.自定义卖商品.UI.34", item => item.CountsAsClass(DamageClass.Melee) && item.pick <= 0 && item.axe <= 0 && item.hammer <= 0 },
                { "Mods.自定义卖商品.UI.35", item => item.CountsAsClass(DamageClass.Ranged) && item.ammo == 0 },
                { "Mods.自定义卖商品.UI.36", item => item.CountsAsClass(DamageClass.Magic) },
                { "Mods.自定义卖商品.UI.37", item => item.CountsAsClass(DamageClass.Summon) && !item.CountsAsClass(DamageClass.SummonMeleeSpeed) && !item.sentry },
                { "Mods.自定义卖商品.UI.38", item => item.CountsAsClass(DamageClass.Summon) && item.sentry },
                { "Mods.自定义卖商品.UI.39", item => item.CountsAsClass(DamageClass.SummonMeleeSpeed) && !item.sentry },
                { "Mods.自定义卖商品.UI.40", item => item.pick > 0 && !ItemID.Sets.IsDrill[item.type] },
                { "Mods.自定义卖商品.UI.41", item => ItemID.Sets.IsDrill[item.type] },
                { "Mods.自定义卖商品.UI.42", item => item.axe > 0 && !ItemID.Sets.IsChainsaw[item.type] },
                { "Mods.自定义卖商品.UI.43", item => ItemID.Sets.IsChainsaw[item.type] },
                { "Mods.自定义卖商品.UI.44", item => item.hammer > 0 },
                { "Mods.自定义卖商品.UI.45", item => item.headSlot >= 0 && !item.vanity },
                { "Mods.自定义卖商品.UI.46", item => item.bodySlot >= 0 && !item.vanity },
                { "Mods.自定义卖商品.UI.47", item => item.shoeSlot >= 0 && !item.vanity },
                { "Mods.自定义卖商品.UI.48", item => item.vanity },
                { "Mods.自定义卖商品.UI.49", item => item.accessory },
                { "Mods.自定义卖商品.UI.50", item => item.accessory && item.expert },
                { "Mods.自定义卖商品.UI.51", item => item.UseSound?.IsTheSameAs(SoundID.Item3) == true && !ItemID.Sets.IsFood[item.type] },
                { "Mods.自定义卖商品.UI.52", item => item.material },
                { "Mods.自定义卖商品.UI.53", item => ItemID.Sets.IsFood[item.type] },
                { "Mods.自定义卖商品.UI.54", item => Main.vanityPet[item.buffType] },
                { "Mods.自定义卖商品.UI.55", item => Main.lightPet[item.buffType] },
                { "Mods.自定义卖商品.UI.56", item => item.mountType != -1 },
                { "Mods.自定义卖商品.UI.57", item => item.mountType != -1 && MountID.Sets.Cart[item.mountType] },
                { "Mods.自定义卖商品.UI.58", item => item.fishingPole > 0 },
                { "Mods.自定义卖商品.UI.59", item => item.bait > 0 },
                { "Mods.自定义卖商品.UI.60", item => item.questItem },
                { "Mods.自定义卖商品.UI.61", item => ItemID.Sets.IsFishingCrate[item.type] },
                { "Mods.自定义卖商品.UI.62", item => ItemID.Sets.BossBag[item.type] && item.expert },
                { "Mods.自定义卖商品.UI.63", item => item.master && item.createTile != -1 },
                { "Mods.自定义卖商品.UI.64", item => item.createTile != -1 },
                { "Mods.自定义卖商品.UI.65", item => item.createWall != -1 },
                { "Mods.自定义卖商品.UI.66", item => item.dye != 0 },
                { "Mods.自定义卖商品.UI.67", item => ItemID.Sets.IsAPickup[item.type] },
                { "Mods.自定义卖商品.UI.68", item => item.ammo > 0 },
                { "Mods.自定义卖商品.UI.69", item => false }
            };
            if (rogueClass != null)
            {
                definitions.Add("Mods.自定义卖商品.UI.Calamity_Rogue", item => item.CountsAsClass(rogueClass));
            }
            return definitions;
        }
        public override void OnInitialize()
        {
            RemoveAllChildren();
            InitializeNpcData();
            mainPanel = new UIPanel();
            mainPanel.Width.Set(1050f, 0f);
            mainPanel.Height.Set(720f, 0f);
            mainPanel.BackgroundColor = new Color(50, 65, 120);
            mainPanel.BorderColor = new Color(80, 100, 160);
            Append(mainPanel);
            UITextPanel<string> closeButton = new("X");
            closeButton.Width.Set(30f, 0f); closeButton.Height.Set(30f, 0f);
            closeButton.Left.Set(-36f, 1f); closeButton.Top.Set(-5f, 0f);
            closeButton.BackgroundColor = new Color(150, 60, 60);
            closeButton.OnLeftClick += (evt, ele) =>
            {
                SoundEngine.PlaySound(SoundID.MenuClose);
                system.HideUI();
            };
            mainPanel.Append(closeButton);
            mainPanel.Append(new UIText(Language.GetText("Mods.自定义卖商品.UI.1"), 1.1f) { HAlign = 0.5f, Top = { Pixels = 10f } });
            InitNPCPanel();
            InitItemPanel();
            InitFilterPanel();
            InitPreviewPanel();
            InitControlButtons();
            InitShopListPanel();
            InitConditionalManagementUI();
            InitConditionBrowserUI();
            InitCurrencyBrowserUI();
            InitNpcDefaultShopPanel();
            PopulateNpcCategoryIcons();
            PopulateNPCList();
            PopulateFilterList();
            PopulateItemList();
            if (currentSelectedNPC == -1)
            {
                if (HasChild(shopSelectionPanel))
                {
                    shopSelectionPanel.Remove();
                }
                if (HasChild(conditionalItemsManagementPanel))
                {
                    conditionalItemsManagementPanel.Remove();
                }
            }
        }
        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
            float screenW = Main.screenWidth;
            float screenH = Main.screenHeight;
            float mainW = 1050f;
            float mainH = 720f;
            float mainLeft = (screenW - mainW) / 2f;
            float mainTop = (screenH - mainH) / 2f;
            mainPanel.Left.Set(mainLeft, 0f);
            mainPanel.Top.Set(mainTop, 0f);
            mainPanel.Recalculate();
            float shopPanelWidth = 180f;
            float shopPanelGap = 10f;
            if (currentSelectedNPC != -1)
            {
                if (!HasChild(shopSelectionPanel))
                {
                    Append(shopSelectionPanel);
                }
                shopSelectionPanel.Left.Set(mainLeft - shopPanelWidth - shopPanelGap, 0f);
                shopSelectionPanel.Top.Set(mainTop + 44f, 0f);
                shopSelectionPanel.Recalculate();
                float rightPanelHeight = 600f;
                float rightPanelGap = 10f;

                if (!HasChild(conditionalItemsManagementPanel))
                {
                    Append(conditionalItemsManagementPanel);
                }
                conditionalItemsManagementPanel.Left.Set(mainLeft + mainW + rightPanelGap, 0f);
                conditionalItemsManagementPanel.Top.Set(mainTop + 44f, 0f);
                conditionalItemsManagementPanel.Height.Set(rightPanelHeight, 0f);
                conditionalItemsManagementPanel.Recalculate();
                if (!HasChild(npcDefaultShopPanel))
                {
                    Append(npcDefaultShopPanel);
                }
                float shopPanelRightEdge = shopSelectionPanel.Left.Pixels + shopSelectionPanel.Width.Pixels;
                npcDefaultShopPanel.Left.Set(shopPanelRightEdge - npcDefaultShopPanel.Width.Pixels, 0f);
                npcDefaultShopPanel.Top.Set(shopSelectionPanel.Top.Pixels + shopSelectionPanel.Height.Pixels + shopPanelGap, 0f);
                float maxAvailableHeight = (mainTop + mainH) - npcDefaultShopPanel.Top.Pixels - shopPanelGap;
                npcDefaultShopPanel.Height.Set(Math.Max(50f, maxAvailableHeight), 0f);
                npcDefaultShopPanel.Recalculate();
            }
            else
            {
                if (HasChild(shopSelectionPanel)) shopSelectionPanel.Remove();
                if (HasChild(conditionalItemsManagementPanel)) conditionalItemsManagementPanel.Remove();
                if (HasChild(npcDefaultShopPanel)) npcDefaultShopPanel.Remove();
            }


            if (isConditionBrowserOpen)
            {
                if (!HasChild(conditionBrowserPanel))
                {
                    Append(conditionBrowserPanel);
                }
                float browserLeft = (screenW - conditionBrowserPanel.Width.Pixels) / 2f;
                float browserTop = (screenH - conditionBrowserPanel.Height.Pixels) / 2f;
                conditionBrowserPanel.Left.Set(browserLeft, 0f);
                conditionBrowserPanel.Top.Set(browserTop, 0f);
                conditionBrowserPanel.Recalculate();
            }
            else
            {
                if (HasChild(conditionBrowserPanel))
                {
                    conditionBrowserPanel.Remove();
                }
            }
            if (isCurrencyBrowserOpen)
            {
                if (!HasChild(currencyBrowserPanel))
                {
                    Append(currencyBrowserPanel);
                }
                float browserLeft = (screenW - currencyBrowserPanel.Width.Pixels) / 2f;
                float browserTop = (screenH - currencyBrowserPanel.Height.Pixels) / 2f;
                currencyBrowserPanel.Left.Set(browserLeft, 0f);
                currencyBrowserPanel.Top.Set(browserTop, 0f);
                currencyBrowserPanel.Recalculate();
            }
            else
            {
                if (HasChild(currencyBrowserPanel))
                {
                    currencyBrowserPanel.Remove();
                }
            }
            bool mouseOverAnyUI = mainPanel.ContainsPoint(Main.MouseScreen) ||
                                  (HasChild(shopSelectionPanel) && shopSelectionPanel.ContainsPoint(Main.MouseScreen)) ||
                                  (HasChild(conditionalItemsManagementPanel) && conditionalItemsManagementPanel.ContainsPoint(Main.MouseScreen)) ||
                                  (HasChild(conditionBrowserPanel) && conditionBrowserPanel.ContainsPoint(Main.MouseScreen)) ||
                                  (HasChild(currencyBrowserPanel) && currencyBrowserPanel.ContainsPoint(Main.MouseScreen));
            if (mouseOverAnyUI)
            {
                Main.LocalPlayer.mouseInterface = true;
            }
            
            HandleNumberInput();
        }
        
        private void HandleNumberInput()
        {
            bool hasActiveInput = false;
            
            foreach (var child in GetAllChildrenRecursive())
            {
                if (child is UINumberInput numberInput && numberInput.isFocused)
                {
                    hasActiveInput = true;
                    activeNumberInput = numberInput;
                    
                    PlayerInput.WritingText = true;
                    Main.blockInput = true;
                    Main.instance.HandleIME();
                    
                    string newText = Main.GetInputText(numberInput.currentText);
                    if (newText != numberInput.currentText)
                    {
                        string filtered = "";
                        foreach (char c in newText)
                        {
                            if (char.IsDigit(c)) filtered += c;
                        }
                        numberInput.currentText = filtered;
                    }
                    
                    if (Main.inputTextEnter)
                    {
                        numberInput.LoseFocus();
                        activeNumberInput = null;
                    }
                    
                    break;
                }
            }
            
            if (!hasActiveInput)
            {
                activeNumberInput = null;
            }
        }
        
        private IEnumerable<UIElement> GetAllChildrenRecursive()
        {
            var stack = new Stack<UIElement>();
            foreach (var child in Children)
            {
                stack.Push(child);
            }
            
            while (stack.Count > 0)
            {
                var current = stack.Pop();
                yield return current;
                
                foreach (var child in current.Children)
                {
                    stack.Push(child);
                }
            }
        }
        public void InitNpcDefaultShopPanel()
        {
            npcDefaultShopPanel = new UIPanel();
            npcDefaultShopPanel.Width.Set(280f, 0f);
            npcDefaultShopPanel.Height.Set(300f, 0f);
            npcDefaultShopPanel.BackgroundColor = new Color(30, 30, 45);
            npcDefaultShopPanel.BorderColor = new Color(60, 60, 80);
            npcDefaultShopPanel.SetPadding(10f);
            npcDefaultShopPanel.Append(new UIText(Language.GetText("Mods.自定义卖商品.UI.DefaultShop"), 0.95f) { HAlign = 0.5f, Top = { Pixels = 5f } });
            npcDefaultShopItemList = new UIList { Width = { Percent = 1f, Pixels = -20f }, Height = { Percent = 1f, Pixels = -45f }, Top = { Pixels = 35f }, ListPadding = 8f };
            npcDefaultShopPanel.Append(npcDefaultShopItemList);
            npcDefaultShopScrollbar = new UIScrollbar();
            npcDefaultShopScrollbar.SetView(100f, 1000f);
            npcDefaultShopScrollbar.Height.Set(-45f, 1f);
            npcDefaultShopScrollbar.Top.Set(35f, 0f);
            npcDefaultShopScrollbar.Left.Set(-15f, 1f);
            npcDefaultShopItemList.SetScrollbar(npcDefaultShopScrollbar);
            npcDefaultShopPanel.Append(npcDefaultShopScrollbar);
        }
        public void InitCurrencyBrowserUI()
        {
            currencyBrowserPanel = new UIPanel();
            currencyBrowserPanel.Width.Set(260f, 0f);
            currencyBrowserPanel.Height.Set(300f, 0f);
            currencyBrowserPanel.BackgroundColor = new Color(40, 40, 60);
            currencyBrowserPanel.BorderColor = new Color(200, 200, 200);
            currencyBrowserPanel.SetPadding(10f);
            currencyBrowserPanel.Append(new UIText(Language.GetText("Mods.自定义卖商品.UI.2"), 1f) { HAlign = 0.5f });
            UITextPanel<string> closeBtn = new("X");
            closeBtn.Width.Set(30f, 0f); closeBtn.Height.Set(30f, 0f);
            closeBtn.Left.Set(-35f, 1f); closeBtn.Top.Set(-5f, 0f);
            closeBtn.BackgroundColor = new Color(150, 60, 60);
            closeBtn.OnLeftClick += (evt, ele) => { isCurrencyBrowserOpen = false; SoundEngine.PlaySound(SoundID.MenuClose); };
            currencyBrowserPanel.Append(closeBtn);
            currencyBrowserList = new UIList { Width = { Percent = 1f }, Height = { Percent = 1f, Pixels = -40f }, Top = { Pixels = 35f }, ListPadding = 5f };
            currencyBrowserPanel.Append(currencyBrowserList);
            currencyBrowserScrollbar = new UIScrollbar();
            currencyBrowserScrollbar.SetView(100f, 1000f);
            currencyBrowserScrollbar.Height.Set(-60f, 1f);
            currencyBrowserScrollbar.Top.Set(45f, 0f);
            currencyBrowserScrollbar.Left.Set(-20f, 1f);
            currencyBrowserList.SetScrollbar(currencyBrowserScrollbar);
            currencyBrowserPanel.Append(currencyBrowserScrollbar);
        }
        public void InitShopListPanel()
        {
            shopSelectionPanel = new UIPanel();
            shopSelectionPanel.Width.Set(180f, 0f);
            shopSelectionPanel.Height.Set(400f, 0f);
            shopSelectionPanel.BackgroundColor = new Color(30, 30, 45);
            shopSelectionPanel.BorderColor = new Color(60, 60, 80);
            shopSelectionPanel.Append(new UIText(Language.GetText("Mods.自定义卖商品.UI.3"), 0.95f) { HAlign = 0.5f, Top = { Pixels = 5f } });
            shopList = new UIList { Width = { Percent = 1f, Pixels = -20f }, Height = { Percent = 1f, Pixels = -40f }, Top = { Pixels = 35f }, ListPadding = 5f };
            shopSelectionPanel.Append(shopList);
            shopScrollbar = new UIScrollbar();
            shopScrollbar.SetView(100f, 1000f);
            shopScrollbar.Height.Set(-40f, 1f);
            shopScrollbar.Top.Set(35f, 0f);
            shopScrollbar.Left.Set(-15f, 1f);
            shopList.SetScrollbar(shopScrollbar);
            shopSelectionPanel.Append(shopScrollbar);
        }
        public void InitConditionalManagementUI()
        {
            conditionalItemsManagementPanel = new UIPanel();
            conditionalItemsManagementPanel.Width.Set(340f, 0f);
            conditionalItemsManagementPanel.BackgroundColor = new Color(35, 45, 60);
            conditionalItemsManagementPanel.BorderColor = new Color(70, 80, 100);
            conditionalItemsManagementPanel.SetPadding(10f);
            conditionalItemsManagementPanel.Append(new UIText(Language.GetText("Mods.自定义卖商品.UI.4"), 1f) { HAlign = 0.5f });
            conditionalItemsManagementPanel.Append(new UIText(Language.GetText("Mods.自定义卖商品.UI.5"), 0.7f) { HAlign = 0.5f, Top = { Pixels = 25f }, TextColor = Color.LightGray });
            conditionalItemsManagementList = new UIList { Width = { Percent = 1f, Pixels = -20f }, Height = { Percent = 1f, Pixels = -50f }, Top = { Pixels = 50f }, ListPadding = 10f };
            conditionalItemsManagementPanel.Append(conditionalItemsManagementList);
            conditionalItemsManagementScrollbar = new UIScrollbar();
            conditionalItemsManagementScrollbar.SetView(100f, 1000f);
            conditionalItemsManagementScrollbar.Height.Set(-50f, 1f);
            conditionalItemsManagementScrollbar.Top.Set(50f, 0f);
            conditionalItemsManagementScrollbar.Left.Set(-15f, 1f);
            conditionalItemsManagementList.SetScrollbar(conditionalItemsManagementScrollbar);
            conditionalItemsManagementPanel.Append(conditionalItemsManagementScrollbar);
        }
        public void InitConditionBrowserUI()
        {
            conditionBrowserPanel = new UIPanel();
            conditionBrowserPanel.Width.Set(300f, 0f);
            conditionBrowserPanel.Height.Set(400f, 0f);
            conditionBrowserPanel.BackgroundColor = new Color(40, 50, 70);
            conditionBrowserPanel.BorderColor = Color.White;
            conditionBrowserPanel.SetPadding(10f);
            conditionBrowserPanel.Append(new UIText(Language.GetText("Mods.自定义卖商品.UI.6"), 1f) { HAlign = 0.5f });
            UITextPanel<string> closeBrowserBtn = new("X");
            closeBrowserBtn.Width.Set(30f, 0f); closeBrowserBtn.Height.Set(30f, 0f);
            closeBrowserBtn.Left.Set(-36f, 1f); closeBrowserBtn.Top.Set(-5f, 0f);
            closeBrowserBtn.BackgroundColor = new Color(150, 60, 60);
            closeBrowserBtn.OnLeftClick += (evt, ele) =>
            {
                isConditionBrowserOpen = false;
                SoundEngine.PlaySound(SoundID.MenuClose);
            };
            conditionBrowserPanel.Append(closeBrowserBtn);
            conditionBrowserList = new UIList { Width = { Percent = 1f, Pixels = -20f }, Height = { Percent = 1f, Pixels = -40f }, Top = { Pixels = 35f }, ListPadding = 6f };
            conditionBrowserPanel.Append(conditionBrowserList);
            conditionBrowserScrollbar = new UIScrollbar();
            conditionBrowserScrollbar.SetView(100f, 1000f);
            conditionBrowserScrollbar.Height.Set(-80f, 1f);
            conditionBrowserScrollbar.Top.Set(45f, 0f);
            conditionBrowserScrollbar.Left.Set(-20f, 1f);
            conditionBrowserList.SetScrollbar(conditionBrowserScrollbar);
            conditionBrowserPanel.Append(conditionBrowserScrollbar);
        }
        public void PopulateNpcDefaultShopPanel()
        {
            npcDefaultShopItemList.Clear();

            if (currentSelectedNPC == -1)
            {
                npcDefaultShopItemList.Add(new UIText(Language.GetText("Mods.自定义卖商品.UI.NoNpcSelectedForDefaultShop"), 0.8f) { HAlign = 0.5f, VAlign = 0.5f, TextColor = Color.Gray });
                return;
            }
            if (currentSelectedNPC == NPCID.TravellingMerchant)
            {
                npcDefaultShopItemList.Add(new UIText(Language.GetText("Mods.自定义卖商品.UI.TravellingMerchantShopCannotPreview"), 0.8f) { HAlign = 0.5f, VAlign = 0.5f, TextColor = Color.LightCoral });
                return;
            }

            List<Item> actualShopItems = [];
            try
            {
                NPCShop targetShop = null;
                foreach (var shop in NPCShopDatabase.AllShops)
                {
                    if (shop.NpcType == currentSelectedNPC && shop.Name == currentSelectedShop)
                    {
                        targetShop = (NPCShop)shop;
                        break;
                    }
                }

                if (targetShop != null)
                {
                    List<Item> tempShopItemsList = [];
                    NPC tempNpc = new();
                    tempNpc.SetDefaults(currentSelectedNPC);
                    targetShop.FillShop(tempShopItemsList, tempNpc);
                    Item[] itemsForModifyHook = [.. tempShopItemsList];
                    CustomShopNPC customShopGlobalNPC = ModContent.GetInstance<CustomShopNPC>();
                    customShopGlobalNPC?.ModifyActiveShop(tempNpc, currentSelectedShop, itemsForModifyHook);
                    actualShopItems.AddRange(itemsForModifyHook.Where(item => item != null && !item.IsAir));
                }
            }
            catch (Exception ex)
            {
                npcDefaultShopItemList.Add(new UIText($"Error loading default shop: {ex.Message}", 0.8f) { HAlign = 0.5f, VAlign = 0.5f, TextColor = Color.Red });
                return;
            }
            List<Item> customShopItems = [];
            try
            {
                if (system.ShopItems.TryGetValue(currentSelectedNPC, out var shopDict) &&
                    shopDict.TryGetValue(currentSelectedShop, out var customEntries))
                {
                    foreach (var entry in customEntries)
                    {
                        if (entry.ItemID > 0)
                        {
                            bool shouldShow = true;

                            if (entry.Condition1Type > 0)
                            {
                                if (!ConditionRegistry.Check(entry.Condition1Type, entry.Condition1Value))
                                {
                                    shouldShow = false;
                                }
                            }

                            if (shouldShow && entry.Condition2Type > 0)
                            {
                                if (!ConditionRegistry.Check(entry.Condition2Type, entry.Condition2Value))
                                {
                                    shouldShow = false;
                                }
                            }

                            if (shouldShow)
                            {
                                Item customItem = new();
                                customItem.SetDefaults(entry.ItemID);
                                customItem.shopCustomPrice = entry.CustomPrice;

                                if (entry.CurrencyID == CustomCurrencyID.None)
                                {
                                    customItem.shopSpecialCurrency = -1;
                                }
                                else
                                {
                                    customItem.shopSpecialCurrency = entry.CurrencyID;
                                }

                                customShopItems.Add(customItem);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                npcDefaultShopItemList.Add(new UIText($"Error loading custom items: {ex.Message}", 0.8f) { HAlign = 0.5f, VAlign = 0.5f, TextColor = Color.Red });
                return;
            }
            List<Item> allItems = [.. actualShopItems, .. customShopItems];
            if (allItems.Count == 0)
            {
                npcDefaultShopItemList.Add(new UIText(Language.GetText("Mods.自定义卖商品.UI.DefaultShopEmpty"), 0.8f) { HAlign = 0.5f, VAlign = 0.5f, TextColor = Color.Gray });
                return;
            }
            int itemsPerRow = 4;
            float itemSlotSize = 52f;
            float itemPadding = 8f;
            float rowHeight = itemSlotSize + itemPadding;
            UIElement currentRow = null;
            int indexInRow = 0;
            if (customShopItems.Count > 0)
            {
                UIText customItemsTitle = new(Language.GetText("Mods.自定义卖商品.UI.CustomItemsTitle") + $" ({customShopItems.Count})", 0.75f)
                {
                    HAlign = 0.5f,
                    Top = { Pixels = 5f },
                    TextColor = Color.LightGreen
                };
                npcDefaultShopItemList.Add(customItemsTitle);
            }

            foreach (var item in allItems)
            {
                if (currentRow == null || indexInRow >= itemsPerRow)
                {
                    currentRow = new UIElement { Width = { Percent = 1f }, Height = { Pixels = rowHeight } };
                    npcDefaultShopItemList.Add(currentRow);
                    indexInRow = 0;
                }
                UIPanel itemPanel = new()
                {
                    Width = { Pixels = itemSlotSize },
                    Height = { Pixels = itemSlotSize },
                    Left = { Pixels = itemPadding + indexInRow * (itemSlotSize + itemPadding) },
                    Top = { Pixels = 2f },
                    BackgroundColor = customShopItems.Contains(item) ? new Color(60, 40, 80) : new Color(40, 40, 55),
                    BorderColor = customShopItems.Contains(item) ? Color.Goldenrod : Color.Black
                };
                UIItemIcon itemIcon = new(this, item.type)
                {
                    HAlign = 0.5f,
                    VAlign = 0.5f,
                    Width = { Pixels = itemSlotSize * 0.85f },
                    Height = { Pixels = itemSlotSize * 0.85f }
                };
                itemPanel.Append(itemIcon);
                string itemName = item.Name;
                bool isCustom = customShopItems.Contains(item);
                itemPanel.OnMouseOver += (evt, ele) =>
                {
                    itemPanel.BorderColor = Color.Gold;
                    itemPanel.BackgroundColor = isCustom ? new Color(80, 60, 100) : new Color(60, 60, 80);
                    string tooltip = itemName;
                    if (isCustom)
                    {
                        tooltip += "\n[自定义物品]";
                    }

                    Main.instance.MouseText(tooltip);
                    Main.LocalPlayer.mouseInterface = true;
                };
                itemPanel.OnMouseOut += (evt, ele) =>
                {
                    itemPanel.BorderColor = isCustom ? Color.Goldenrod : Color.Black;
                    itemPanel.BackgroundColor = isCustom ? new Color(60, 40, 80) : new Color(40, 40, 55);
                };
                currentRow.Append(itemPanel);
                indexInRow++;
            }
        }
        public void PopulateConditionalItemsManagementList()
        {
            conditionalItemsManagementList.Clear();
            if (currentSelectedNPC == -1 || string.IsNullOrEmpty(currentSelectedShop))
            {
                conditionalItemsManagementList.Add(new UIText(Language.GetText("Mods.自定义卖商品.UI.7"), 0.8f) { HAlign = 0.5f, VAlign = 0.5f, TextColor = Color.Gray });
                return;
            }
            if (!system.ShopItems.TryGetValue(currentSelectedNPC, out var dict) || !dict.TryGetValue(currentSelectedShop, out var list))
            {
                conditionalItemsManagementList.Add(new UIText(Language.GetText("Mods.自定义卖商品.UI.8"), 0.8f) { HAlign = 0.5f, VAlign = 0.5f, TextColor = Color.Gray });
                return;
            }
            for (int i = 0; i < list.Count; i++)
            {
                var entry = list[i];
                Item item = new Item();
                item.SetDefaults(entry.ItemID);
                UIElement row = new() { Width = { Percent = 1f }, Height = { Pixels = 150f } };
                UIPanel rowBg = new() { Width = { Percent = 1f }, Height = { Percent = 1f }, BackgroundColor = new Color(40, 40, 50, 200), BorderColor = Color.Transparent };
                rowBg.SetPadding(0);
                row.Append(rowBg);
                UIPanel itemIconPanel = new() { Width = { Pixels = 40f }, Height = { Pixels = 40f }, Left = { Pixels = 10f }, Top = { Pixels = 10f }, BackgroundColor = new Color(60, 60, 70) };
                itemIconPanel.Append(new UIItemIcon(this, entry.ItemID) { HAlign = 0.5f, VAlign = 0.5f, Width = { Pixels = 30f }, Height = { Pixels = 30f } });
                rowBg.Append(itemIconPanel);
                UIPanel deleteItemBtn = new() { Width = { Pixels = 40f }, Height = { Pixels = 20f }, Left = { Pixels = 10f }, Top = { Pixels = 55f }, BackgroundColor = new Color(120, 40, 40) };
                deleteItemBtn.Append(new UIText(Language.GetText("Mods.自定义卖商品.UI.9"), 0.65f) { HAlign = 0.5f, VAlign = 0.5f });
                int currentEntryItemID = entry.ItemID;
                deleteItemBtn.OnLeftClick += (evt, ele) =>
                {
                    system.RemoveShopItem(currentSelectedNPC, currentSelectedShop, currentEntryItemID);
                    UpdateSelectedItemsList();
                    PopulateConditionalItemsManagementList();
                    SoundEngine.PlaySound(SoundID.MenuClose);
                };
                rowBg.Append(deleteItemBtn);
                UIText itemNameText = new(item.Name, 0.75f) { Left = { Pixels = 60f }, Top = { Pixels = 20f }, TextColor = Color.LightGray };
                rowBg.Append(itemNameText);
                UIText priceLabel = new(Language.GetText("Mods.自定义卖商品.UI.10"), 0.7f) { Left = { Pixels = 10f }, Top = { Pixels = 80f }, TextColor = Color.Gold };
                rowBg.Append(priceLabel);
                int currentIndex = i;
                long defaultPrice = item.value;
                UINumberInput priceInput = new(defaultPrice.ToString(), entry.CustomPrice, (val) =>
                {
                    system.UpdateItemPrice(currentSelectedNPC, currentSelectedShop, currentIndex, val);
                });
                priceInput.onFocusChanged = () =>
                {
                    if (searchBar != null)
                    {
                        searchBar.ToggleTakingText();
                    }
                };
                priceInput.Width.Set(80f, 0f);
                priceInput.Height.Set(24f, 0f);
                priceInput.Left.Set(10f, 0f);
                priceInput.Top.Set(100f, 0f);
                rowBg.Append(priceInput);
                int currentCurrencyIconItemID = GetCurrencyIconItemID(entry.CurrencyID);
                UIPanel currencySelectorBtn = new();
                currencySelectorBtn.Width.Set(30f, 0f);
                currencySelectorBtn.Height.Set(30f, 0f);
                currencySelectorBtn.Left.Set(95f, 0f);
                currencySelectorBtn.Top.Set(97f, 0f);
                currencySelectorBtn.BackgroundColor = new Color(60, 60, 80);
                currencySelectorBtn.BorderColor = Color.Goldenrod;
                UIItemIcon currencyIconInBtn = new(this, currentCurrencyIconItemID)
                {
                    HAlign = 0.5f,
                    VAlign = 0.5f
                };
                currencyIconInBtn.Width.Set(24f, 0f);
                currencyIconInBtn.Height.Set(24f, 0f);
                currencyIconInBtn.IgnoresMouseInteraction = true;
                Texture2D itemTexture = Terraria.GameContent.TextureAssets.Item[ItemID.GoldCoin].Value;
                if (ContentSamples.ItemsByType.ContainsKey(currentCurrencyIconItemID))
                {
                    itemTexture = Terraria.GameContent.TextureAssets.Item[currentCurrencyIconItemID].Value;
                }
                UIImage currencyIconImage = new(itemTexture)
                {
                    HAlign = 0.5f,
                    VAlign = 0.5f,
                    Width = { Pixels = 24f },
                    Height = { Pixels = 24f },
                    ScaleToFit = true,
                    IgnoresMouseInteraction = true
                };
                currencySelectorBtn.Append(currencyIconImage);
                currencySelectorBtn.OnLeftClick += (evt, ele) =>
                {
                    currentTargetCurrencyItemIndex = currentIndex;
                    PopulateCurrencyBrowserList();
                    isCurrencyBrowserOpen = true;
                    SoundEngine.PlaySound(SoundID.MenuOpen);
                };
                currencySelectorBtn.OnMouseOver += (evt, ele) =>
                {
                    currencySelectorBtn.BorderColor = Color.White;
                    Main.instance.MouseText((string)Language.GetText("Mods.自定义卖商品.UI.11"));
                };
                currencySelectorBtn.OnMouseOut += (evt, ele) => { currencySelectorBtn.BorderColor = Color.Goldenrod; };
                rowBg.Append(currencySelectorBtn);
                float cond1Left = 170f;
                UIPanel conditionSlot1Panel = CreateConditionSlotPanel(entry.Condition1Type, entry.Condition1Value, i, 1);
                conditionSlot1Panel.Left.Set(cond1Left, 0f);
                conditionSlot1Panel.Top.Set(10f, 0f);
                rowBg.Append(conditionSlot1Panel);
                UIPanel delCond1Btn = new() { Width = { Pixels = 40f }, Height = { Pixels = 20f }, Left = { Pixels = cond1Left }, Top = { Pixels = 55f }, BackgroundColor = new Color(80, 50, 50) };
                delCond1Btn.Append(new UIText(Language.GetText("Mods.自定义卖商品.UI.12"), 0.65f) { HAlign = 0.5f, VAlign = 0.5f });
                delCond1Btn.OnLeftClick += (evt, ele) =>
                {
                    system.UpdateItemCondition(currentSelectedNPC, currentSelectedShop, i, 1, 0, 0);
                    PopulateConditionalItemsManagementList();
                    SoundEngine.PlaySound(SoundID.MenuTick);
                };
                rowBg.Append(delCond1Btn);
                float cond2Left = 230f;
                UIPanel conditionSlot2Panel = CreateConditionSlotPanel(entry.Condition2Type, entry.Condition2Value, i, 2);
                conditionSlot2Panel.Left.Set(cond2Left, 0f);
                conditionSlot2Panel.Top.Set(10f, 0f);
                rowBg.Append(conditionSlot2Panel);
                UIPanel delCond2Btn = new() { Width = { Pixels = 40f }, Height = { Pixels = 20f }, Left = { Pixels = cond2Left }, Top = { Pixels = 55f }, BackgroundColor = new Color(80, 50, 50) };
                delCond2Btn.Append(new UIText(Language.GetText("Mods.自定义卖商品.UI.12"), 0.65f) { HAlign = 0.5f, VAlign = 0.5f });
                delCond2Btn.OnLeftClick += (evt, ele) =>
                {
                    system.UpdateItemCondition(currentSelectedNPC, currentSelectedShop, i, 2, 0, 0);
                    PopulateConditionalItemsManagementList();
                    SoundEngine.PlaySound(SoundID.MenuTick);
                };
                rowBg.Append(delCond2Btn);
                conditionalItemsManagementList.Add(row);
            }
        }
        public static int GetCurrencyIconItemID(int currencyID)
        {
            var info = CurrencyRegistry.RegisteredCurrencies.FirstOrDefault(c => c.CurrencyID == currencyID);
            if (info != null)
            {
                return info.IconItemID;
            }
            return ItemID.GoldCoin;
        }
        public void PopulateCurrencyBrowserList()
        {
            currencyBrowserList.Clear();
            int itemsPerRow = 4;
            float spacing = 55f;
            UIElement currentRow = null;
            int indexInRow = 0;
            var allCurrencies = CurrencyRegistry.RegisteredCurrencies;
            var sortedCurrencies = allCurrencies.OrderBy(c => c.Name).ToList();
            for (int i = 0; i < sortedCurrencies.Count; i++)
            {
                if (currentRow == null || indexInRow >= itemsPerRow)
                {
                    currentRow = new UIElement { Width = { Percent = 1f }, Height = { Pixels = 50f } };
                    currencyBrowserList.Add(currentRow);
                    indexInRow = 0;
                }
                var currencyInfo = sortedCurrencies[i];
                UIPanel iconPanel = new() { Width = { Pixels = 44f }, Height = { Pixels = 44f }, Left = { Pixels = indexInRow * spacing + 5f }, BackgroundColor = new Color(40, 40, 50) };
                UIItemIcon currencyIcon = new(this, currencyInfo.IconItemID)
                {
                    HAlign = 0.5f,
                    VAlign = 0.5f
                };
                currencyIcon.Width.Set(32f, 0f);
                currencyIcon.Height.Set(32f, 0f);
                iconPanel.Append(currencyIcon);
                int currentSelectedCurrencyID = currencyInfo.CurrencyID;
                string currentName = currencyInfo.Name;
                iconPanel.OnLeftClick += (evt, ele) =>
                {
                    if (currentTargetCurrencyItemIndex != -1)
                    {
                        system.UpdateItemCurrency(currentSelectedNPC, currentSelectedShop, currentTargetCurrencyItemIndex, currentSelectedCurrencyID);
                        PopulateConditionalItemsManagementList();
                        isCurrencyBrowserOpen = false;
                        SoundEngine.PlaySound(SoundID.MenuTick);
                    }
                };
                iconPanel.OnMouseOver += (evt, ele) =>
                {
                    iconPanel.BackgroundColor = new Color(60, 60, 80);
                    Main.instance.MouseText(currentName);
                };
                iconPanel.OnMouseOut += (evt, ele) => { iconPanel.BackgroundColor = new Color(40, 40, 50); };
                currentRow.Append(iconPanel);
                indexInRow++;
            }
        }
        public UIPanel CreateConditionSlotPanel(int conditionType, int conditionValue, int itemIndex, int conditionSlot)
        {
            UIPanel panel = new() { Width = { Pixels = 40f }, Height = { Pixels = 40f }, BackgroundColor = new Color(30, 30, 40), BorderColor = Color.Black };
            ConditionInfo info = ConditionRegistry.GetInfo(conditionType, conditionValue);
            if (info != null)
            {
                if (ModContent.RequestIfExists<Texture2D>(info.IconPath, out var tex))
                {
                    UIImage conditionImage = new(tex);
                    conditionImage.Width.Set(30f, 0f);
                    conditionImage.Height.Set(30f, 0f);
                    conditionImage.HAlign = 0.5f;
                    conditionImage.VAlign = 0.5f;
                    conditionImage.ScaleToFit = true;
                    panel.Append(conditionImage);
                }
                else
                {
                    panel.Append(new UIText(info.Name.Substring(0, 1), 0.8f) { HAlign = 0.5f, VAlign = 0.5f });
                }
                panel.OnMouseOver += (evt, ele) =>
                {
                    Main.instance.MouseText(info.Name);
                    panel.BorderColor = Color.Yellow;
                };
            }
            else
            {
                panel.Append(new UIText("?", 0.8f) { HAlign = 0.5f, VAlign = 0.5f, TextColor = Color.Gray });
            }
            panel.OnLeftClick += (evt, ele) =>
            {
                isConditionBrowserOpen = true;
                currentTargetItemIndex = itemIndex;
                currentTargetConditionSlot = conditionSlot;
                PopulateConditionBrowserList();
                SoundEngine.PlaySound(SoundID.MenuOpen);
            };
            panel.OnMouseOver += (evt, ele) => { panel.BorderColor = Color.Yellow; Main.LocalPlayer.mouseInterface = true; };
            panel.OnMouseOut += (evt, ele) => { panel.BorderColor = Color.Black; };
            return panel;
        }
        public void PopulateConditionBrowserList()
        {
            conditionBrowserList.Clear();
            int itemsPerRow = 5;
            float spacing = 52f;
            UIElement currentRow = null;
            int indexInRow = 0;
            UIElement noConditionRow = new() { Width = { Percent = 1f }, Height = { Pixels = 50f } };
            conditionBrowserList.Add(noConditionRow);
            UIPanel noConditionPanel = new() { Width = { Pixels = 44f }, Height = { Pixels = 44f }, Left = { Pixels = 5f }, BackgroundColor = new Color(60, 60, 60) };
            noConditionPanel.Append(new UIText(Language.GetText("Mods.自定义卖商品.UI.13"), 0.9f) { HAlign = 0.5f, VAlign = 0.5f });
            noConditionPanel.OnLeftClick += (evt, ele) => ApplySelectedCondition(0, 0);
            noConditionRow.Append(noConditionPanel);
            List<ConditionInfo> targetList = null;
            int typeID = 0;
            if (currentTargetConditionSlot == 1)
            {
                targetList = ConditionRegistry.BossConditions;
                typeID = 1;
            }
            else if (currentTargetConditionSlot == 2)
            {
                targetList = ConditionRegistry.EnvironmentConditions;
                typeID = 2;
            }
            if (targetList != null)
            {
                for (int i = 0; i < targetList.Count; i++)
                {
                    if (currentRow == null || indexInRow >= itemsPerRow)
                    {
                        currentRow = new UIElement { Width = { Percent = 1f }, Height = { Pixels = 50f } };
                        conditionBrowserList.Add(currentRow);
                        indexInRow = 0;
                    }
                    var info = targetList[i];
                    UIPanel iconPanel = new() { Width = { Pixels = 44f }, Height = { Pixels = 44f }, Left = { Pixels = indexInRow * spacing + 5f }, BackgroundColor = new Color(40, 40, 50) };
                    if (ModContent.RequestIfExists<Texture2D>(info.IconPath, out var tex))
                    {
                        UIImage icon = new UIImage(tex);
                        icon.HAlign = 0.5f; icon.VAlign = 0.5f;
                        icon.Width.Set(32f, 0f); icon.Height.Set(32f, 0f);
                        icon.ScaleToFit = true;
                        iconPanel.Append(icon);
                    }
                    else
                    {
                        iconPanel.Append(new UIText(info.Name, 0.6f) { HAlign = 0.5f, VAlign = 0.5f });
                    }
                    int currentVal = i;
                    iconPanel.OnLeftClick += (evt, ele) => ApplySelectedCondition(typeID, currentVal);
                    iconPanel.OnMouseOver += (evt, ele) =>
                    {
                        iconPanel.BackgroundColor = new Color(60, 60, 80);
                        Main.instance.MouseText(info.Name);
                    };
                    iconPanel.OnMouseOut += (evt, ele) => { iconPanel.BackgroundColor = new Color(40, 40, 50); };
                    currentRow.Append(iconPanel);
                    indexInRow++;
                }
            }
        }
        public void ApplySelectedCondition(int cType, int cVal)
        {
            if (currentTargetItemIndex != -1 && currentTargetConditionSlot != -1)
            {
                system.UpdateItemCondition(currentSelectedNPC, currentSelectedShop, currentTargetItemIndex, currentTargetConditionSlot, cType, cVal);
                PopulateConditionalItemsManagementList();
                isConditionBrowserOpen = false;
                SoundEngine.PlaySound(SoundID.MenuTick);
            }
        }
        public void InitNPCPanel()
        {
            UIPanel npcPanel = new() { Width = { Pixels = 260f }, Height = { Pixels = 520f }, Left = { Pixels = 12f }, Top = { Pixels = 44f }, BackgroundColor = new Color(35, 35, 50) };
            mainPanel.Append(npcPanel);
            npcPanel.Append(new UIText(Language.GetText("Mods.自定义卖商品.UI.14"), 0.95f) { HAlign = 0.5f, Top = { Pixels = -4f } });
            UIElement catWrapper = new() { Top = { Pixels = 24f }, Width = { Pixels = 50f }, Height = { Percent = 1f, Pixels = -24f } };
            npcPanel.Append(catWrapper);
            npcCategoryList = new UIList { Width = { Percent = 1f, Pixels = -12f }, Height = { Percent = 1f }, ListPadding = 6f };
            catWrapper.Append(npcCategoryList);
            UIScrollbar catScroll = new() { Left = { Pixels = -10f, Percent = 1f }, Width = { Pixels = 20f }, Height = { Percent = 1f } };
            catScroll.SetView(100f, 1000f);
            npcCategoryList.SetScrollbar(catScroll);
            catWrapper.Append(catScroll);
            UIElement listWrapper = new() { Top = { Pixels = 24f }, Left = { Pixels = 60f }, Width = { Percent = 1f, Pixels = -60f }, Height = { Percent = 1f, Pixels = -24f } };
            npcPanel.Append(listWrapper);
            npcList = new UIList { Width = { Percent = 1f, Pixels = -20f }, Height = { Percent = 1f }, ListPadding = 6f };
            listWrapper.Append(npcList);
            npcScrollbar = new UIScrollbar { Left = { Pixels = -16f, Percent = 1f }, Width = { Pixels = 20f }, Height = { Percent = 1f } };
            npcScrollbar.SetView(100f, 1000f);
            npcList.SetScrollbar(npcScrollbar);
            listWrapper.Append(npcScrollbar);
        }
        public void InitItemPanel()
        {
            UIPanel itemPanel = new() { Width = { Pixels = 540f }, Height = { Pixels = 460f }, Left = { Pixels = 284f }, Top = { Pixels = 44f }, BackgroundColor = new Color(35, 35, 50) };
            mainPanel.Append(itemPanel);
            UIText selectItemText = new(Language.GetText("Mods.自定义卖商品.UI.15"), 1f) { HAlign = 0.5f, Top = { Pixels = 6f } };
            itemPanel.Append(selectItemText);
            float sortButtonWidth = 50f;
            float sortButtonHeight = 25f;
            float sortButtonGap = 5f;
            float sortButtonLeftStart = 10f;
            float sortButtonTop = 10f;
            UITextPanel<string> idSortBtn = CreateSortButton("ID", sortButtonWidth, sortButtonHeight, sortButtonLeftStart, sortButtonTop);
            idSortBtn.OnLeftClick += (evt, ele) => { SetSortMode("ID"); SoundEngine.PlaySound(SoundID.MenuTick); };
            itemPanel.Append(idSortBtn);
            UITextPanel<string> valueSortBtn = CreateSortButton((string)Language.GetText("Mods.自定义卖商品.UI.16"), sortButtonWidth, sortButtonHeight, sortButtonLeftStart + sortButtonWidth + sortButtonGap, sortButtonTop);
            valueSortBtn.OnLeftClick += (evt, ele) => { SetSortMode((string)Language.GetText("Mods.自定义卖商品.UI.16")); SoundEngine.PlaySound(SoundID.MenuTick); };
            itemPanel.Append(valueSortBtn);
            UITextPanel<string> alphaSortBtn = CreateSortButton((string)Language.GetText("Mods.自定义卖商品.UI.17"), sortButtonWidth, sortButtonHeight, sortButtonLeftStart + (sortButtonWidth + sortButtonGap) * 2, sortButtonTop);
            alphaSortBtn.OnLeftClick += (evt, ele) => { SetSortMode((string)Language.GetText("Mods.自定义卖商品.UI.17")); SoundEngine.PlaySound(SoundID.MenuTick); };
            itemPanel.Append(alphaSortBtn);
            float verticalOffset = sortButtonHeight + sortButtonTop + 5f;
            searchBoxPanel = new UIPanel();
            searchBoxPanel.SetPadding(0);
            searchBoxPanel.Width.Set(-20f, 1f);
            searchBoxPanel.Height.Set(28f, 0f);
            searchBoxPanel.Left.Set(10f, 0f);
            searchBoxPanel.Top.Set(verticalOffset, 0f);
            searchBoxPanel.BackgroundColor = new Color(28, 28, 36);
            searchBoxPanel.BorderColor = Color.Black;
            searchBoxPanel.OnLeftClick += (evt, element) => searchBar.ToggleTakingText();
            itemPanel.Append(searchBoxPanel);
            searchBar = new UISearchBar(Language.GetText("Mods.自定义卖商品.UI.18"), 0.8f);
            searchBar.Width.Set(0f, 1f);
            searchBar.Height.Set(0f, 1f);
            searchBar.HAlign = 0.5f;
            searchBar.VAlign = 0.5f;
            searchBar.Left.Set(10f, 0f);
            searchBar.OnContentsChanged += (text) => { currentSearchText = text; currentPage = 0; PopulateItemList(); };
            searchBoxPanel.Append(searchBar);
            
            float itemListTop = verticalOffset + searchBoxPanel.Height.Pixels + 10f;
            float itemListHeightAdjust = itemListTop + 144f;
            itemList = new UIList { Left = { Pixels = 8f }, Top = { Pixels = itemListTop }, Width = { Percent = 1f, Pixels = -16f }, Height = { Percent = 1f, Pixels = -itemListHeightAdjust }, ListPadding = 6f };
            itemPanel.Append(itemList);
            itemScrollbar = new UIScrollbar { Height = { Percent = 1f, Pixels = -itemListHeightAdjust }, Left = { Percent = 1f, Pixels = -20f }, Top = { Pixels = itemListTop } };
            itemScrollbar.SetView(100f, 1000f);
            itemList.SetScrollbar(itemScrollbar);
            itemPanel.Append(itemScrollbar);
            prevPageBtn = new UIPanel();
            prevPageBtn.Width.Set(80f, 0f);
            prevPageBtn.Height.Set(30f, 0f);
            prevPageBtn.Top.Set(-36f, 1f);
            prevPageBtn.Left.Set(10f, 0f);
            prevPageBtn.BackgroundColor = new Color(60, 60, 80);
            prevPageBtn.Append(new UIText(Language.GetText("Mods.自定义卖商品.UI.19"), 0.9f) { HAlign = 0.5f, VAlign = 0.5f });
            prevPageBtn.OnLeftClick += (evt, ele) => { if (currentPage > 0) { currentPage--; PopulateItemList(); SoundEngine.PlaySound(SoundID.MenuTick); } };
            itemPanel.Append(prevPageBtn);
            nextPageBtn = new UIPanel();
            nextPageBtn.Width.Set(80f, 0f);
            nextPageBtn.Height.Set(30f, 0f);
            nextPageBtn.Top.Set(-36f, 1f);
            nextPageBtn.Left.Set(-90f, 1f);
            nextPageBtn.BackgroundColor = new Color(60, 60, 80);
            nextPageBtn.Append(new UIText(Language.GetText("Mods.自定义卖商品.UI.20"), 0.9f) { HAlign = 0.5f, VAlign = 0.5f });
            nextPageBtn.OnLeftClick += (evt, ele) => { currentPage++; PopulateItemList(); SoundEngine.PlaySound(SoundID.MenuTick); };
            itemPanel.Append(nextPageBtn);
            pageText = new UIText("1 / 1", 0.9f) { HAlign = 0.5f, Top = { Pixels = -28f, Percent = 1f } };
            itemPanel.Append(pageText);
        }
        public UITextPanel<string> CreateSortButton(string text, float width, float height, float left, float top)
        {
            UITextPanel<string> btn = new(text, 0.7f)
            {
                Width = { Pixels = width },
                Height = { Pixels = height },
                Left = { Pixels = left },
                Top = { Pixels = top },
                BackgroundColor = currentSortMode == text ? new Color(80, 100, 180) : new Color(60, 60, 70)
            };
            btn.OnMouseOver += (evt, ele) => { btn.BackgroundColor = new Color(90, 110, 190); Main.LocalPlayer.mouseInterface = true; };
            btn.OnMouseOut += (evt, ele) => { btn.BackgroundColor = currentSortMode == text ? new Color(80, 100, 180) : new Color(60, 60, 70); };
            return btn;
        }
        public void SetSortMode(string mode)
        {
            currentSortMode = mode;
            currentPage = 0;
            InitItemPanel();
            PopulateItemList();
        }
        public void InitFilterPanel()
        {
            UIPanel filterPanel = new() { Width = { Pixels = 180f }, Height = { Pixels = 460f }, Left = { Pixels = 836f }, Top = { Pixels = 44f }, BackgroundColor = new Color(35, 35, 50) };
            mainPanel.Append(filterPanel);
            filterPanel.Append(new UIText(Language.GetText("Mods.自定义卖商品.UI.21"), 0.95f) { HAlign = 0.5f, Top = { Pixels = 6f } });
            filterList = new UIList { Left = { Pixels = 0f }, Top = { Pixels = 34f }, Width = { Percent = 1f, Pixels = -16f }, Height = { Percent = 1f, Pixels = -40f }, ListPadding = 4f };
            filterPanel.Append(filterList);
            filterScrollbar = new UIScrollbar { Height = { Percent = 1f, Pixels = -40f }, Left = { Percent = 1f, Pixels = -20f }, Top = { Pixels = 34f } };
            filterScrollbar.SetView(100f, 1000f);
            filterList.SetScrollbar(filterScrollbar);
            filterPanel.Append(filterScrollbar);
        }
        public void InitPreviewPanel()
        {
            UIPanel previewPanel = new() { Width = { Pixels = 732f }, Height = { Pixels = 110f }, Left = { Pixels = 284f }, Top = { Pixels = 516f }, BackgroundColor = new Color(35, 35, 50) };
            mainPanel.Append(previewPanel);
            previewPanel.Append(new UIText(Language.GetText("Mods.自定义卖商品.UI.22"), 0.95f) { HAlign = 0.5f, Top = { Pixels = 6f } });
            selectedItemsList = new UIList { Left = { Pixels = 8f }, Top = { Pixels = 54f }, Width = { Percent = 1f, Pixels = -16f }, Height = { Percent = 1f, Pixels = -40f }, ListPadding = 6f };
            previewPanel.Append(selectedItemsList);
            selectedItemsScrollbar = new UIScrollbar { Height = { Percent = 1f, Pixels = -40f }, Left = { Percent = 1f, Pixels = -20f }, Top = { Pixels = 32f } };
            selectedItemsScrollbar.SetView(100f, 1000f);
            selectedItemsList.SetScrollbar(selectedItemsScrollbar);
            previewPanel.Append(selectedItemsScrollbar);
            UIPanel leftPreview = new() { Width = { Pixels = 260f }, Height = { Pixels = 110f }, Left = { Pixels = 12f }, Top = { Pixels = 576f }, BackgroundColor = new Color(35, 35, 50) };
            mainPanel.Append(leftPreview);
            leftPreview.Append(new UIText(Language.GetText("Mods.自定义卖商品.UI.23"), 0.95f) { HAlign = 0.5f, Top = { Pixels = 6f } });
            UIElement row = new() { Width = { Percent = 1f }, Height = { Pixels = 64f }, Top = { Pixels = 30f } };
            leftPreview.Append(row);
            npcHeadImage = new UINPCIcon(NPCID.Guide, true) { Width = { Pixels = 64f }, Height = { Pixels = 64f }, Left = { Pixels = 8f }, VAlign = 0.5f };
            row.Append(npcHeadImage);
            selectedNpcName = new UIText(Language.GetText("Mods.自定义卖商品.UI.24"), 0.9f) { Left = { Pixels = 84f }, VAlign = 0.5f, TextColor = Color.LightGray };
            row.Append(selectedNpcName);
        }
        public void InitControlButtons()
        {
            float buttonWidth = 120f;
            float buttonHeight = 34f;
            float gap = 15f;
            float startX = 320f;
            float topY = 660f;
            UITextPanel<string> confirm = new(Language.GetTextValue("Mods.自定义卖商品.UI.25"))
            {
                Width = { Pixels = buttonWidth },
                Height = { Pixels = buttonHeight },
                Left = { Pixels = startX },
                Top = { Pixels = topY },
                BackgroundColor = new Color(60, 120, 60)
            };
            confirm.OnLeftClick += (evt, ele) => { SoundEngine.PlaySound(SoundID.MenuOpen); };
            mainPanel.Append(confirm);
            UITextPanel<string> importBtn = new(Language.GetTextValue("Mods.自定义卖商品.UI.26"))
            {
                Width = { Pixels = buttonWidth },
                Height = { Pixels = buttonHeight },
                Left = { Pixels = startX + (buttonWidth + gap) * 1 },
                Top = { Pixels = topY },
                BackgroundColor = new Color(40, 80, 120)
            };
            importBtn.OnLeftClick += (evt, ele) =>
            {
                system.ImportConfig();
                UpdateSelectedItemsList();
                PopulateConditionalItemsManagementList();
                SoundEngine.PlaySound(SoundID.MenuTick);
            };
            mainPanel.Append(importBtn);
            UITextPanel<string> exportBtn = new(Language.GetTextValue("Mods.自定义卖商品.UI.27"))
            {
                Width = { Pixels = buttonWidth },
                Height = { Pixels = buttonHeight },
                Left = { Pixels = startX + (buttonWidth + gap) * 2 },
                Top = { Pixels = topY },
                BackgroundColor = new Color(40, 80, 120)
            };
            exportBtn.OnLeftClick += (evt, ele) =>
            {
                system.ExportConfig();
                SoundEngine.PlaySound(SoundID.MenuTick);
            };
            mainPanel.Append(exportBtn);
            UITextPanel<string> clear = new(Language.GetTextValue("Mods.自定义卖商品.UI.28"))
            {
                Width = { Pixels = buttonWidth },
                Height = { Pixels = buttonHeight },
                Left = { Pixels = startX + (buttonWidth + gap) * 3 },
                Top = { Pixels = topY },
                BackgroundColor = new Color(150, 80, 40)
            };
            clear.OnLeftClick += (evt, ele) =>
            {
                if (currentSelectedNPC != -1 && system.ShopItems.TryGetValue(currentSelectedNPC, out var dict) && dict.TryGetValue(currentSelectedShop, out var list))
                {
                    list.Clear(); UpdateSelectedItemsList(); PopulateConditionalItemsManagementList(); SoundEngine.PlaySound(SoundID.MenuClose);
                }
            };
            mainPanel.Append(clear);
            UITextPanel<string> reset = new(Language.GetTextValue(Language.GetTextValue("Mods.自定义卖商品.UI.29")))
            {
                Width = { Pixels = buttonWidth },
                Height = { Pixels = buttonHeight },
                Left = { Pixels = startX + (buttonWidth + gap) * 4 },
                Top = { Pixels = topY },
                BackgroundColor = new Color(150, 40, 40)
            };
            reset.OnLeftClick += (evt, ele) => { system.ShopItems.Clear(); system.HasCustomShopItems.Clear(); currentSelectedNPC = -1; UpdateSelectedItemsList(); PopulateConditionalItemsManagementList(); SoundEngine.PlaySound(SoundID.MenuClose); };
            mainPanel.Append(reset);
        }
        public void InitializeNpcData()
        {
            npcDataByMod.Clear();
            npcDataByMod["Terraria"] = [.. ManualNPCList];
            foreach (ModNPC modNpc in ModContent.GetContent<ModNPC>())
            {
                if (modNpc.NPC.townNPC)
                {
                    string modName = modNpc.Mod.Name;
                    if (!npcDataByMod.ContainsKey(modName)) npcDataByMod[modName] = new List<int>();
                    npcDataByMod[modName].Add(modNpc.Type);
                }
            }
        }
        public void PopulateNpcCategoryIcons()
        {
            npcCategoryList.Clear();
            AddNpcCategoryButton("Terraria", "自定义卖商品/Assets/Textures/UIs/Icon");
            foreach (string modName in npcDataByMod.Keys.OrderBy(name => name))
            {
                if (modName != "Terraria")
                {
                    AddNpcCategoryButton(modName, null);
                }
            }
        }
        public void AddNpcCategoryButton(string categoryKey, string iconPath)
        {
            UIPanel btn = new();
            btn.Width.Set(40f, 0f);
            btn.Height.Set(40f, 0f);
            btn.SetPadding(0);
            bool isSelected = currentNpcModFilter == categoryKey;
            btn.BackgroundColor = isSelected ? new Color(100, 120, 180) : new Color(60, 60, 70);
            btn.BorderColor = isSelected ? Color.White : Color.Black;
            Asset<Texture2D> iconAsset = null;
            if (categoryKey == "Terraria")
            {
                if (ModContent.RequestIfExists<Texture2D>(iconPath, out var asset)) iconAsset = asset;
            }
            else
            {
                if (ModLoader.TryGetMod(categoryKey, out Mod mod))
                {
                    if (mod.HasAsset("icon_small")) iconAsset = mod.Assets.Request<Texture2D>("icon_small");
                    else iconAsset = ModContent.Request<Texture2D>("自定义卖商品/Assets/Textures/UIs/Icon1");
                }
                else iconAsset = ModContent.Request<Texture2D>("自定义卖商品/Assets/Textures/UIs/Icon1");
            }
            if (iconAsset != null)
            {
                UIImage icon = new(iconAsset)
                {
                    HAlign = 0.5f,
                    VAlign = 0.5f
                };
                icon.Width.Set(32f, 0f); icon.Height.Set(32f, 0f); icon.ScaleToFit = true;
                btn.Append(icon);
            }
            else
            {
                UIText text = new(categoryKey[..1].ToUpper(), 1f) { HAlign = 0.5f, VAlign = 0.5f };
                btn.Append(text);
            }
            btn.OnLeftClick += (evt, ele) =>
            {
                if (currentNpcModFilter != categoryKey)
                {
                    currentNpcModFilter = categoryKey;
                    SoundEngine.PlaySound(SoundID.MenuTick);
                    PopulateNpcCategoryIcons();
                    PopulateNPCList();
                }
            };
            npcCategoryList.Add(btn);
        }
        public static string GetNPCDisplayNameSafe(int npcType)
        {
            try
            {
                if (npcType < NPCID.Count)
                {
                    string name = Lang.GetNPCNameValue(npcType);
                    return !string.IsNullOrEmpty(name) ? name : $"原版NPC_{npcType}";
                }
                else
                {
                    ModNPC modNpc = ModContent.GetModNPC(npcType);
                    return modNpc != null ? (modNpc.DisplayName?.ToString() ?? modNpc.Name) : $"ModNPC_{npcType}";
                }
            }
            catch (Exception) { return $"NPC_{npcType}"; }
        }
        public void PopulateNPCList()
        {
            npcList.Clear();
            if (!npcDataByMod.TryGetValue(currentNpcModFilter, out List<int> npcsToShow))
            {
                return;
            }
            foreach (int npcType in npcsToShow.OrderBy(id => GetNPCDisplayNameSafe(id)))
            {
                try
                {
                    UIPanel npcItem = new();
                    npcItem.Width.Set(0f, 1f);
                    npcItem.Height.Set(56f, 0f);
                    npcItem.BackgroundColor = new Color(60, 60, 70);
                    string npcDisplayName = GetNPCDisplayNameSafe(npcType);
                    UINPCIcon head = new(npcType, false) { VAlign = 0.5f, Left = { Pixels = 6f }, Width = { Pixels = 32f }, Height = { Pixels = 32f } };
                    npcItem.Append(head);
                    UIText nameText = new(npcDisplayName, 0.8f) { VAlign = 0.5f, Left = { Pixels = 60f }, TextColor = Color.LightGray };
                    npcItem.Append(nameText);
                    int currentNpcType = npcType;
                    string currentNpcName = npcDisplayName;
                    npcItem.OnLeftClick += (evt, element) =>
                    {
                        currentSelectedNPC = currentNpcType;
                        currentSelectedShop = "Shop";
                        PopulateShopList(currentNpcType);
                        UpdateSelectedItemsList();
                        PopulateConditionalItemsManagementList();
                        PopulateNpcDefaultShopPanel();
                        npcHeadImage.SetNPC(currentNpcType);
                        selectedNpcName?.SetText(currentNpcName);
                        SoundEngine.PlaySound(SoundID.MenuTick);
                    };
                    npcItem.OnMouseOver += (evt, element) => { npcItem.BackgroundColor = new Color(80, 80, 100); Main.instance.MouseText(currentNpcName); Main.LocalPlayer.mouseInterface = true; };
                    npcItem.OnMouseOut += (evt, element) => { npcItem.BackgroundColor = new Color(60, 60, 70); };
                    npcList.Add(npcItem);
                }
                catch { continue; }
            }
        }
        public void PopulateShopList(int npcType)
        {
            shopList.Clear();
            var shops = NPCShopDatabase.AllShops.Where(s => s.NpcType == npcType).Select(s => s.Name).ToList();
            if (shops.Count == 0) shops.Add("Shop");
            if (!shops.Contains(currentSelectedShop)) currentSelectedShop = shops[0];
            foreach (string shopName in shops)
            {
                UIPanel shopBtn = new();
                shopBtn.Width.Set(0f, 1f);
                shopBtn.Height.Set(30f, 0f);
                bool isSelected = shopName == currentSelectedShop;
                shopBtn.BackgroundColor = isSelected ? new Color(100, 120, 180) : new Color(50, 50, 60);
                shopBtn.BorderColor = isSelected ? Color.White : Color.Black;
                UIText text = new(shopName, 0.8f) { HAlign = 0.5f, VAlign = 0.5f };
                shopBtn.Append(text);
                string thisShopName = shopName;
                shopBtn.OnLeftClick += (evt, ele) =>
                {
                    if (currentSelectedShop != thisShopName)
                    {
                        currentSelectedShop = thisShopName;
                        SoundEngine.PlaySound(SoundID.MenuTick);
                        PopulateShopList(npcType);
                        UpdateSelectedItemsList();
                        PopulateConditionalItemsManagementList();
                        PopulateNpcDefaultShopPanel();
                    }
                };
                shopList.Add(shopBtn);
            }
        }
        public void PopulateFilterList()
        {
            filterList.Clear();
            var definitions = GetFilterDefinitions();
            string allKey = "Mods.自定义卖商品.UI.30";
            if (string.IsNullOrEmpty(currentCategory))
            {
                if (definitions.TryGetValue(allKey, out Func<Item, bool> value))
                    AddFilterButton(allKey, value);
                foreach (var categoryKey in CategoryStructure.Keys)
                    filterList.Add(CreateCategoryButton(categoryKey));
                HashSet<string> keysInCategories = new HashSet<string>();
                foreach (var list in CategoryStructure.Values)
                    foreach (var key in list) keysInCategories.Add(key);
                foreach (var kvp in definitions)
                {
                    if (kvp.Key == allKey || keysInCategories.Contains(kvp.Key)) continue;
                    AddFilterButton(kvp.Key, kvp.Value);
                }
            }
            else
            {
                filterList.Add(CreateBackButton());
                if (CategoryStructure.TryGetValue(currentCategory, out List<string> subItems))
                {
                    foreach (string itemFilterKey in subItems)
                    {
                        if (definitions.TryGetValue(itemFilterKey, out var func))
                            AddFilterButton(itemFilterKey, func);
                    }
                }
            }
        }
        public void AddFilterButton(string key, Func<Item, bool> filterFunc)
        {
            UIPanel filterButton = new();
            filterButton.Width.Set(0f, 1f);
            filterButton.Height.Set(36f, 0f);
            bool isSelected = key == currentFilterKey;
            filterButton.BackgroundColor = isSelected ? new Color(80, 100, 180) : new Color(60, 60, 70);
            filterButton.BorderColor = Color.Black;
            string displayText = key.StartsWith("Mods.") ? Language.GetTextValue(key) : key;
            UIText text = new(displayText, 0.85f) { HAlign = 0.5f, VAlign = 0.5f };
            filterButton.Append(text);
            filterButton.OnLeftClick += (evt, element) =>
            {
                currentFilterKey = key;
                currentPage = 0;
                PopulateFilterList();
                PopulateItemList();
                SoundEngine.PlaySound(SoundID.MenuTick);
            };
            filterList.Add(filterButton);
        }
        public UIPanel CreateCategoryButton(string categoryKey)
        {
            UIPanel btn = new();
            btn.Width.Set(0f, 1f);
            btn.Height.Set(36f, 0f);
            btn.BackgroundColor = new Color(45, 55, 45);
            btn.BorderColor = Color.Black;
            string displayText = Language.GetTextValue(categoryKey);
            UIText text = new(displayText + " >", 0.95f) { HAlign = 0.5f, VAlign = 0.5f };
            btn.Append(text);
            btn.OnLeftClick += (evt, element) =>
            {
                currentCategory = categoryKey;
                PopulateFilterList();
                SoundEngine.PlaySound(SoundID.MenuOpen);
            };
            return btn;
        }
        public UIPanel CreateBackButton()
        {
            UIPanel btn = new();
            btn.Width.Set(0f, 1f);
            btn.Height.Set(30f, 0f);
            btn.BackgroundColor = new Color(100, 50, 50);
            btn.BorderColor = Color.Black;
            UIText text = new(Language.GetText("Mods.自定义卖商品.UI.31"), 0.9f) { HAlign = 0.5f, VAlign = 0.5f };
            btn.Append(text);
            btn.OnLeftClick += (evt, element) => { currentCategory = ""; PopulateFilterList(); SoundEngine.PlaySound(SoundID.MenuClose); };
            return btn;
        }
        public void PopulateItemList()
        {
            itemList.Clear();
            var definitions = GetFilterDefinitions();
            var filterCondition = definitions.TryGetValue(currentFilterKey, out var fc) ? fc : item => true;
            bool hasSearchText = !string.IsNullOrEmpty(currentSearchText);
            List<int> allPossibleItemIDs = new();
            for (int i = 1; i < ItemLoader.ItemCount; i++)
            {
                if (!ContentSamples.ItemsByType.TryGetValue(i, out Item item)) continue;
                if (item.type <= ItemID.None || string.IsNullOrEmpty(item.Name) || item.Name.Contains("Unloaded")) continue;
                if (!filterCondition(item)) continue;
                if (hasSearchText && item.Name.IndexOf(currentSearchText, StringComparison.OrdinalIgnoreCase) == -1) continue;
                allPossibleItemIDs.Add(i);
            }
            IEnumerable<int> sortedItemIDs = allPossibleItemIDs;
            switch (currentSortMode)
            {
                case "ID":
                    sortedItemIDs = allPossibleItemIDs
                    .OrderBy(id => id < ItemID.Count ? 0 : 1)
                  .ThenBy(id => id);
                    break;
                case "价值":
                    ///
                    sortedItemIDs = allPossibleItemIDs.OrderByDescending(id => ContentSamples.ItemsByType[id].value);
                    break;
                case "字母":
                    ///
                    sortedItemIDs = allPossibleItemIDs.OrderBy(id => ContentSamples.ItemsByType[id].Name);
                    break;
            }
            List<int> validItemIDs = [.. sortedItemIDs];
            int totalPages = (int)Math.Ceiling((double)validItemIDs.Count / ITEMS_PER_PAGE);
            if (totalPages == 0) totalPages = 1;
            if (currentPage >= totalPages) currentPage = totalPages - 1;
            if (currentPage < 0) currentPage = 0;
            pageText.SetText($"{currentPage + 1} / {totalPages}");
            int startIndex = currentPage * ITEMS_PER_PAGE;
            int endIndex = Math.Min(startIndex + ITEMS_PER_PAGE, validItemIDs.Count);
            int itemsPerRow = 6;
            UIElement currentRow = null;
            int indexInRow = 0;
            for (int i = startIndex; i < endIndex; i++)
            {
                int itemType = validItemIDs[i];
                if (!ContentSamples.ItemsByType.TryGetValue(itemType, out Item item)) continue;
                if (currentRow == null || indexInRow >= itemsPerRow)
                {
                    currentRow = new UIElement { Width = { Percent = 1f }, Height = { Pixels = 100f } };
                    itemList.Add(currentRow);
                    indexInRow = 0;
                }
                UIPanel itemPanel_Item = new() { Width = { Pixels = 50f }, Height = { Pixels = 50f }, Left = { Pixels = 12f + indexInRow * 85f }, Top = { Pixels = 4f }, BackgroundColor = new Color(38, 38, 48) }; // Renamed variable to avoid conflict
                itemPanel_Item.Append(new UIItemIcon(this, itemType) { HAlign = 0.5f, VAlign = 0.5f, Width = { Pixels = 40f }, Height = { Pixels = 40f } });
                UIPanel addBtn = new() { Width = { Pixels = 50f }, Height = { Pixels = 24f }, Left = { Pixels = 12f + indexInRow * 85f }, Top = { Pixels = 56f }, BackgroundColor = new Color(40, 120, 40) };
                addBtn.Append(new UIText(Language.GetTextValue("Mods.自定义卖商品.UI.32"), 0.75f) { HAlign = 0.5f, VAlign = 0.5f });
                addBtn.OnLeftClick += (evt, element) => { OnItemAdd(itemType); };
                currentRow.Append(itemPanel_Item);
                currentRow.Append(addBtn);
                string itemName = item.Name;
                itemPanel_Item.OnMouseOver += (evt, element) => { itemPanel_Item.BackgroundColor = new Color(50, 50, 70); Main.instance.MouseText(itemName); Main.LocalPlayer.mouseInterface = true; };
                itemPanel_Item.OnMouseOut += (evt, element) => { itemPanel_Item.BackgroundColor = new Color(38, 38, 48); };
                indexInRow++;
            }
        }
        public void OnItemAdd(int itemType)
        {
            if (currentSelectedNPC == -1) { return; }
            if (!system.ShopItems.TryGetValue(currentSelectedNPC, out var shopDict))
            {
                shopDict = [];
                system.ShopItems[currentSelectedNPC] = shopDict;
                system.HasCustomShopItems[currentSelectedNPC] = true;
            }
            if (!shopDict.TryGetValue(currentSelectedShop, out var items))
            {
                items = [];
                shopDict[currentSelectedShop] = items;
            }
            if (!items.Any(x => x.ItemID == itemType))
            {
                items.Add(new ShopItemEntry(itemType, 0, 0, 0, 0));
                UpdateSelectedItemsList();
                PopulateConditionalItemsManagementList();
                SoundEngine.PlaySound(SoundID.MenuTick);
            }
            else
            {
            }
        }
        public void UpdateSelectedItemsList()
        {
            selectedItemsList.Clear();
            if (currentSelectedNPC != -1 && system.ShopItems.TryGetValue(currentSelectedNPC, out var dict) && dict.TryGetValue(currentSelectedShop, out var list))
            {
                int itemsPerRow = 13;
                UIElement currentRow = null;
                int idx = 0;
                for (int i = 0; i < list.Count; i++)
                {
                    if (currentRow == null || idx >= itemsPerRow)
                    {
                        currentRow = new UIElement { Width = { Percent = 1f }, Height = { Pixels = 48f } };
                        selectedItemsList.Add(currentRow);
                        idx = 0;
                    }
                    var entry = list[i];
                    UIPanel p = new() { Width = { Pixels = 40f }, Height = { Pixels = 40f }, Left = { Pixels = 10f + idx * 52f }, Top = { Pixels = 2f }, BackgroundColor = new Color(50, 50, 60) };
                    p.Append(new UIItemIcon(this, entry.ItemID) { HAlign = 0.5f, VAlign = 0.5f, Width = { Pixels = 30f }, Height = { Pixels = 30f } });
                    UIPanel deleteItemBtn = new() { Width = { Pixels = 16f }, Height = { Pixels = 16f }, Left = { Pixels = 42f }, Top = { Pixels = 0f }, BackgroundColor = new Color(120, 40, 40) };
                    deleteItemBtn.Append(new UIText("X", 0.7f) { HAlign = 0.5f, VAlign = 0.5f });
                    int currentEntryItemID = entry.ItemID;
                    deleteItemBtn.OnLeftClick += (evt, ele) =>
                    {
                        system.RemoveShopItem(currentSelectedNPC, currentSelectedShop, currentEntryItemID);
                        UpdateSelectedItemsList();
                        PopulateConditionalItemsManagementList();
                        SoundEngine.PlaySound(SoundID.MenuClose);
                    };
                    p.Append(deleteItemBtn);
                    currentRow.Append(p);
                    idx++;
                }
            }
        }
    }
}