﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using ReLogic.Content;
using System;
using Terraria;
using Terraria.GameContent;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.UI;
namespace 自定义卖商品.Common.UIs
{
    public class UINPCIcon : UIElement
    {
        public int _npcType;
        public Asset<Texture2D> _texture;
        public bool _isHead;
        public int _frameCount;
        public int _currentFrame;
        public int _frameTimer;
        public bool _animate;
        public UINPCIcon(int npcType, bool animate = true)
        {
            _animate = animate;
            SetNPC(npcType);
        }
        public void SetNPC(int npcType)
        {
            if (_npcType == npcType && _texture != null) return;
            _npcType = npcType;
            _currentFrame = 0;
            _frameTimer = 0;
            LoadTexture();
        }
        public void LoadTexture()
        {
            _texture = null;
            _isHead = false;
            _frameCount = 1;
            if (_npcType >= 0 && _npcType < NPCID.Count)
            {
                int headIndex = NPC.TypeToDefaultHeadIndex(_npcType);
                if (headIndex >= 0 && headIndex < TextureAssets.NpcHead.Length && TextureAssets.NpcHead[headIndex] != null)
                {
                    _texture = TextureAssets.NpcHead[headIndex];
                    _isHead = true;
                    return;
                }
                if (_npcType == NPCID.SkeletonMerchant)
                {
                    _texture = ModContent.Request<Texture2D>("自定义卖商品/Assets/Textures/UIs/NPC_453");
                    _isHead = true;
                    return;
                }
            }
            ModNPC modNpc = ModContent.GetModNPC(_npcType);
            if (modNpc != null && ModContent.RequestIfExists<Texture2D>(modNpc.Texture + "_Head", out var headAsset))
            {
                _texture = headAsset;
                _isHead = true;
                return;
            }
            if (_npcType >= 0 && _npcType < TextureAssets.Npc.Length && TextureAssets.Npc[_npcType] != null)
            {
                _texture = TextureAssets.Npc[_npcType];
                _isHead = false;
                _frameCount = Main.npcFrameCount[_npcType];
            }
            else
            {
                _texture = TextureAssets.Npc[0];
            }
        }
        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
            if (_animate && !_isHead && _frameCount > 1)
            {
                _frameTimer++;
                if (_frameTimer >= 6) { _frameTimer = 0; _currentFrame = (_currentFrame + 1) % _frameCount; }
            }
        }
        protected override void DrawSelf(SpriteBatch spriteBatch)
        {
            if (_texture == null || _texture.Value == null) return;
            Texture2D tex = _texture.Value;
            Rectangle sourceRect = _isHead ? tex.Bounds : new Rectangle(0, (tex.Height / (_frameCount > 0 ? _frameCount : 1)) * _currentFrame, tex.Width, tex.Height / (_frameCount > 0 ? _frameCount : 1));
            CalculatedStyle dimensions = GetDimensions();
            float scale = Math.Min(dimensions.Width / sourceRect.Width, dimensions.Height / sourceRect.Height);
            if (scale > 1f) scale = 1f;
            spriteBatch.Draw(tex, dimensions.Position() + new Vector2(dimensions.Width, dimensions.Height) / 2f, sourceRect, Color.White, 0f, sourceRect.Size() / 2f, scale, SpriteEffects.None, 0f);
        }
    }
}