﻿using System.Collections.Generic;
namespace 自定义卖商品.Common.Helpers
{
    public class ShopDataModel
    {
        public string ShopName;
        public List<ItemDataModel> Items = new();
    }
}