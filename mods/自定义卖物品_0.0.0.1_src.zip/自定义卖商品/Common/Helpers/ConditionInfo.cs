﻿using System;
using Terraria.Localization;
namespace 自定义卖商品.Common.Helpers
{
    public class ConditionInfo(string localizationKey, string iconFileName, Func<bool> predicate)
    {
        public string LocalizationKey { get; } = localizationKey;
        public string IconPath { get; } = $"自定义卖商品/Assets/Textures/Conditions/{iconFileName}";
        public Func<bool> Predicate { get; } = predicate;
        public string Name => Language.GetTextValue(LocalizationKey);
    }
}