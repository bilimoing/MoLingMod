﻿using System.Collections.Generic;
namespace 自定义卖商品.Common.Helpers
{
    public class ExportDataModel
    {
        public int NPCID;
        public string NPCName;
        public List<ShopDataModel> Shops = [];
    }
}