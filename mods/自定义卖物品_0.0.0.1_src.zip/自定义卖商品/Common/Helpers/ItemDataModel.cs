﻿namespace 自定义卖商品.Common.Helpers
{
    public class ItemDataModel
    {
        public int ItemID;
        public string ItemName;
        public int C1Type;
        public int C1Val;
        public int C2Type;
        public int C2Val;
        public int CustomPrice = -1;
        public int CurrencyID;
    }
}