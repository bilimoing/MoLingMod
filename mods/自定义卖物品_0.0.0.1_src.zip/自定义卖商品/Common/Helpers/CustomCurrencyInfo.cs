﻿namespace 自定义卖商品.Common.Helpers
{
    public class CustomCurrencyInfo
    {
        public string Name { get; set; }
        public int CurrencyID { get; set; }
        public int IconItemID { get; set; }
    }
}