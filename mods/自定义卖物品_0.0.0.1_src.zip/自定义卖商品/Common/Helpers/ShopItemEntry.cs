﻿namespace 自定义卖商品.Common.Helpers
{
    public class ShopItemEntry(int id, int type1 = 0, int val1 = 0, int type2 = 0, int val2 = 0, int customPrice = -1, int currencyID = 0)
    {
        public int ItemID = id;
        public int Condition1Type = type1;
        public int Condition1Value = val1;
        public int Condition2Type = type2;
        public int Condition2Value = val2;
        public int CustomPrice = customPrice;
        public int CurrencyID = currencyID;
        public ShopItemEntry Clone() => new(ItemID, Condition1Type, Condition1Value, Condition2Type, Condition2Value, CustomPrice, CurrencyID);
    }
}