﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Reflection;
using Terraria;
using Terraria.GameContent.Events;
using Terraria.ID;
using Terraria.ModLoader;
namespace 自定义卖商品.Common.Helpers
{
    public static class ConditionRegistry
    {
        public static List<ConditionInfo> BossConditions = [];
        public static List<ConditionInfo> EnvironmentConditions = [];
        public static void Load()
        {
            BossConditions.Clear();
            EnvironmentConditions.Clear();
            #region 击败条件
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.79", "KingSlime", () => NPC.downedSlimeKing));
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.80", "EyeOfCthulhu", () => NPC.downedBoss1));
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.81", "EvilBoss", () => NPC.downedBoss2));
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.82", "Deerclops", () => NPC.downedDeerclops));
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.83", "Skeletron", () => NPC.downedBoss3));
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.84", "QueenBee", () => NPC.downedQueenBee));
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.85", "WallOfFlesh", () => Main.hardMode));
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.86", "QueenSlime", () => NPC.downedQueenSlime));
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.87", "MechBoss3", () => NPC.downedMechBoss3));
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.88", "MechBoss2", () => NPC.downedMechBoss2));
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.89", "MechBoss1", () => NPC.downedMechBoss1));
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.90", "Plantera", () => NPC.downedPlantBoss));
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.91", "Golem", () => NPC.downedGolemBoss));
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.92", "DukeFishron", () => NPC.downedFishron));
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.93", "EmpressOfLight", () => NPC.downedEmpressOfLight));
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.94", "Cultist", () => NPC.downedAncientCultist));
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.95", "MoonLord", () => NPC.downedMoonlord));
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.96", "IceQueen", () => NPC.downedChristmasIceQueen));
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.97", "PumpkinMoon", () => NPC.downedHalloweenKing));
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.98", "PumpkinMoonHard", () => NPC.downedHalloweenTree));
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.99", "SantaNK1", () => NPC.downedChristmasSantank));
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.100", "Everscream", () => NPC.downedChristmasTree));
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.101", "MartianSaucer", () => NPC.downedMartians));
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.102", "GoblinInvasion", () => NPC.downedGoblins));
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.103", "PirateInvasion", () => NPC.downedPirates));
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.104", "SolarPillar", () => NPC.downedTowerSolar));
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.105", "StellarPillar", () => NPC.downedTowerStardust));
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.106", "NebulaPillar", () => NPC.downedTowerNebula));
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.107", "VortexPillar", () => NPC.downedTowerVortex));
            BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.108", "DD2Legion", () => DD2Event.DownedInvasionAnyDifficulty));
            #endregion
            #region 灾厄Mod (Calamity Mod) 击败条件
            if (ModLoader.TryGetMod("CalamityMod", out Mod calamityMod))
            {
                Type downedBossSystemType = calamityMod.Code.GetType("CalamityMod.DownedBossSystem");
                if (downedBossSystemType != null)
                {
                    Func<bool> CreateCalamityCondition(string fieldName)
                    {
                        FieldInfo field = downedBossSystemType.GetField(fieldName, BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.Public);
                        if (field != null)
                        {
                            return () => (bool)field.GetValue(null);
                        }
                        else
                        {
                            return () => false;
                        }
                    }
                    // 荒漠灾虫
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_DesertScourge", "DesertScourge", CreateCalamityCondition("_downedDesertScourge")));
                    // 菌生蟹
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_Crabulon", "Crabulon", CreateCalamityCondition("_downedCrabulon")));
                    // 腐巢意志
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_HiveMind", "HiveMind", CreateCalamityCondition("_downedHiveMind")));
                    // 血肉宿主
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_Perforator", "Perforator", CreateCalamityCondition("_downedPerforator")));
                    // 史莱姆之神
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_SlimeGod", "SlimeGod", CreateCalamityCondition("_downedSlimeGod")));
                    // 极地之灵
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_Cryogen", "Cryogen", CreateCalamityCondition("_downedCryogen")));
                    // 渊海灾虫
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_AquaticScourge", "AquaticScourge", CreateCalamityCondition("_downedAquaticScourge")));
                    // 硫磺火元素
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_BrimstoneElemental", "BrimstoneElemental", CreateCalamityCondition("_downedBrimstoneElemental")));
                    // 灾厄之影 (克隆体)
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_CalamitasClone", "CalamitasClone", CreateCalamityCondition("_downedCalamitasClone")));
                    // 利维坦
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_Leviathan", "Leviathan", CreateCalamityCondition("_downedLeviathan")));
                    // 白金星舰
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_AstrumAureus", "AstrumAureus", CreateCalamityCondition("_downedAstrumAureus")));
                    // 瘟疫使者歌莉娅
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_Plaguebringer", "Plaguebringer", CreateCalamityCondition("_downedPlaguebringer")));
                    // 毁灭魔像
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_Ravager", "Ravager", CreateCalamityCondition("_downedRavager")));
                    // 星神游龙
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_AstrumDeus", "AstrumDeus", CreateCalamityCondition("_downedAstrumDeus")));
                    // 亵渎守卫
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_Guardians", "ProfanedGuardians", CreateCalamityCondition("_downedGuardians")));
                    // 痴愚金龙
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_Dragonfolly", "Dragonfolly", CreateCalamityCondition("_downedDragonfolly")));
                    // 亵渎天神
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_Providence", "Providence", CreateCalamityCondition("_downedProvidence")));
                    // 无尽虚空
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_CeaselessVoid", "CeaselessVoid", CreateCalamityCondition("_downedCeaselessVoid")));
                    // 风暴编织者
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_StormWeaver", "StormWeaver", CreateCalamityCondition("_downedStormWeaver")));
                    // 西格纳斯
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_Signus", "Signus", CreateCalamityCondition("_downedSignus")));
                    // 噬魂幽花
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_Polterghast", "Polterghast", CreateCalamityCondition("_downedPolterghast")));
                    // 老核弹 (硫海遗爵)
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_BoomerDuke", "OldDuke", CreateCalamityCondition("_downedBoomerDuke")));
                    // 神明吞噬者
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_DoG", "DevourerOfGods", CreateCalamityCondition("_downedDoG")));
                    // 丛林龙
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_Yharon", "Yharon", CreateCalamityCondition("_downedYharon")));
                    // 星流巨械 (Exo Mechs)
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_ExoMechs", "ExoMechs", CreateCalamityCondition("_downedExoMechs")));
                    // 至尊灾厄
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_Calamitas", "SupremeCalamitas", CreateCalamityCondition("_downedCalamitas")));
                    // 始源幻海妖 (成年幻海妖)
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_PrimordialWyrm", "PrimordialWyrm", CreateCalamityCondition("_downedPrimordialWyrm")));
                    // Boss Rush
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_BossRush", "BossRush", CreateCalamityCondition("_downedBossRush")));
                    // 酸雨事件 第一阶段
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_AcidRainT1", "AcidRainT1", CreateCalamityCondition("_downedEoCAcidRain")));
                    // 酸雨事件 第二阶段
                    BossConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_AcidRainT2", "AcidRainT2", CreateCalamityCondition("_downedAquaticScourgeAcidRain")));
                }
            }
            #endregion

            #region 环境条件
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.109", "1", () => Main.LocalPlayer.ZoneForest));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.110", "2", () => Main.LocalPlayer.ZoneDirtLayerHeight));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.111", "3", () => Main.LocalPlayer.ZoneRockLayerHeight));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.112", "4", () => Main.LocalPlayer.ZoneDesert));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.113", "5", () => Main.LocalPlayer.ZoneUndergroundDesert));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.114", "6", () => Main.LocalPlayer.ZoneSnow));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.115", "7", () => Main.LocalPlayer.ZoneSnow && Main.LocalPlayer.ZoneNormalUnderground));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.116", "8", () => Main.LocalPlayer.ZoneCorrupt));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.117", "9", () => Main.LocalPlayer.ZoneCorrupt && Main.LocalPlayer.ZoneNormalUnderground));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.118", "10", () => Main.LocalPlayer.ZoneCorrupt && Main.LocalPlayer.ZoneDesert));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.119", "11", () => Main.LocalPlayer.ZoneCorrupt && Main.LocalPlayer.ZoneUndergroundDesert));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.120", "12", () => Main.LocalPlayer.ZoneCorrupt && Main.LocalPlayer.ZoneSnow));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.121", "13", () => Main.LocalPlayer.ZoneCrimson));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.122", "14", () => Main.LocalPlayer.ZoneCrimson && Main.LocalPlayer.ZoneNormalUnderground));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.123", "15", () => Main.LocalPlayer.ZoneCrimson && Main.LocalPlayer.ZoneDesert));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.124", "16", () => Main.LocalPlayer.ZoneCrimson && Main.LocalPlayer.ZoneUndergroundDesert));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.125", "17", () => Main.LocalPlayer.ZoneCrimson && Main.LocalPlayer.ZoneSnow));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.126", "18", () => Main.LocalPlayer.ZoneHallow));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.127", "19", () => Main.LocalPlayer.ZoneHallow && Main.LocalPlayer.ZoneNormalUnderground));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.128", "20", () => Main.LocalPlayer.ZoneHallow && Main.LocalPlayer.ZoneDesert));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.129", "21", () => Main.LocalPlayer.ZoneHallow && Main.LocalPlayer.ZoneUndergroundDesert));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.130", "22", () => Main.LocalPlayer.ZoneHallow && Main.LocalPlayer.ZoneSnow));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.131", "23", () => Main.LocalPlayer.ZoneJungle));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.132", "24", () => Main.LocalPlayer.ZoneJungle && Main.LocalPlayer.ZoneNormalUnderground));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.133", "25", () => Main.LocalPlayer.ZoneGlowshroom));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.134", "26", () => Main.LocalPlayer.ZoneGlowshroom && Main.LocalPlayer.ZoneNormalUnderground));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.135", "27", () => Main.LocalPlayer.ZoneSkyHeight));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.136", "28", () => Main.LocalPlayer.ZoneBeach));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.137", "29", () => Main.LocalPlayer.ZoneBeach && Main.LocalPlayer.position.Y >= Main.worldSurface * 16f));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.138", "30", () => Main.LocalPlayer.ZoneMarble));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.139", "31", () => Main.LocalPlayer.ZoneGranite));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.140", "32", () => Main.LocalPlayer.ZoneLihzhardTemple));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.141", "33", () => Main.LocalPlayer.ZoneDungeon));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.142", "34", () => Main.LocalPlayer.ZoneUnderworldHeight));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.143", "35", () => IsPositionSpiderCave()));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.144", "36", () => Main.LocalPlayer.ZoneGraveyard));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.145", "37", () => Main.dayTime));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.146", "38", () => !Main.dayTime));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.147", "39", () => Main.bloodMoon));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.148", "40", () => Main.eclipse));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.149", "41", () => Main.raining));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.150", "42", () => Main.IsItAHappyWindyDay));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.151", "44", () => Sandstorm.Happening));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.152", "45", () => Main.LocalPlayer.ZoneMeteor));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.153", "46", () => Main.halloween));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.154", "47", () => Main.xMas));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.155", "48", () => Main.slimeRain));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.156", "49", () => BirthdayParty.PartyIsUp));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.157", "50", () => Main.invasionType == InvasionID.GoblinArmy));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.158", "51", () => Main.invasionType == InvasionID.PirateInvasion));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.159", "52", () => Main.pumpkinMoon));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.160", "53", () => Main.snowMoon));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.161", "54", () => Main.invasionType == InvasionID.MartianMadness));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.162", "55", () => Main.invasionType == InvasionID.SnowLegion));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.163", "56", () => DD2Event.Ongoing));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.164", "57", () => Main.LocalPlayer.ZoneTowerSolar));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.165", "58", () => Main.LocalPlayer.ZoneTowerVortex));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.166", "59", () => Main.LocalPlayer.ZoneTowerNebula));
            EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.167", "60", () => Main.LocalPlayer.ZoneTowerStardust));
            #endregion
            #region 灾厄Mod (Calamity Mod) 环境条件
            if (ModLoader.TryGetMod("CalamityMod", out Mod calamityMod1))
            {
                Func<bool> CreateBiomeCondition(string biomeClassName)
                {
                    if (calamityMod1.TryFind<ModBiome>(biomeClassName, out ModBiome biome))
                    {
                        return () => Main.LocalPlayer.InModBiome(biome);
                    }
                    return () => false;
                }
                Func<bool> CreateMultiBiomeCondition(params string[] biomeClassNames)
                {
                    List<ModBiome> biomes = [];
                    foreach (var name in biomeClassNames)
                    {
                        if (calamityMod1.TryFind(name, out ModBiome b)) biomes.Add(b);
                    }
                    if (biomes.Count == 0) return () => false;
                    return () =>
                    {
                        foreach (var b in biomes)
                        {
                            if (Main.LocalPlayer.InModBiome(b)) return true;
                        }
                        return false;
                    };
                }

                // 硫磺海
                EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_ZoneSulphur", "Calamity_Sulphur", CreateBiomeCondition("SulphurousSeaBiome")));
                // 沉沦之海
                EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_ZoneSunkenSea", "Calamity_SunkenSea", CreateBiomeCondition("SunkenSeaBiome")));
                // 硫火之崖
                EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_ZoneBrimstoneCrag", "Calamity_BrimstoneCrag", CreateBiomeCondition("BrimstoneCragsBiome")));
                // 星辉瘟疫
                EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_ZoneAstral", "Calamity_Astral", CreateMultiBiomeCondition("AstralInfectionBiome")));
                // 深渊
                EnvironmentConditions.Add(new ConditionInfo("Mods.自定义卖商品.UI.Calamity_ZoneAbyss", "Calamity_Abyss", CreateMultiBiomeCondition("AbyssLayer1Biome", "AbyssLayer2Biome", "AbyssLayer3Biome", "AbyssLayer4Biome")));
            }
            #endregion
        }
        public static bool IsPositionSpiderCave()
        {
            Player player = Main.LocalPlayer;
            if (player == null) return false;
            Vector2 position = player.Center;
            int tileX = (int)(position.X / 16);
            int tileY = (int)(position.Y / 16);
            for (int i = -2; i <= 2; i++)
            {
                for (int j = -2; j <= 2; j++)
                {
                    Tile tile = Framing.GetTileSafely(tileX + i, tileY + j);
                    if (tile.WallType == WallID.SpiderUnsafe)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        public static void Unload()
        {
            BossConditions.Clear();
            EnvironmentConditions.Clear();
        }
        public static ConditionInfo GetInfo(int type, int index)
        {
            if (type == 1 && index >= 0 && index < BossConditions.Count)
                return BossConditions[index];
            if (type == 2 && index >= 0 && index < EnvironmentConditions.Count)
                return EnvironmentConditions[index];
            return null;
        }
        public static bool Check(int type, int index)
        {
            if (type == 0) return true;
            var info = GetInfo(type, index);
            return info != null && info.Predicate();
        }
    }
}