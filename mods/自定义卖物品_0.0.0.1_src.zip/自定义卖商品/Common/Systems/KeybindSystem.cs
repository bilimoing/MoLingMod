﻿using Terraria.ModLoader;
namespace 自定义卖商品.Common.Systems
{
    public class KeybindSystem : ModSystem
    {
        public static ModKeybind OpenUI;
        public override void Load()
        {
            OpenUI = KeybindLoader.RegisterKeybind(Mod, "OpenUI", "O");
        }
        public override void Unload()
        {
            OpenUI = null;
        }
    }
}
