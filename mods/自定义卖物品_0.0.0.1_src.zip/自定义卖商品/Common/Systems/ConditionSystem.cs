﻿using Terraria.ModLoader;
using 自定义卖商品.Common.Helpers;
namespace 自定义卖商品.Common.Systems
{
    public class ConditionSystem : ModSystem
    {
        public override void OnModLoad() => ConditionRegistry.Load();
        public override void OnModUnload() => ConditionRegistry.Unload();
    }
}