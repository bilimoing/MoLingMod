﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Terraria;
using Terraria.GameContent.UI;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;
using 自定义卖商品.Common.Helpers;
namespace 自定义卖商品.Common.Systems
{
    public class CurrencyRegistry : ModSystem
    {
        public static List<CustomCurrencyInfo> _registeredCurrencies = [];
        public static IReadOnlyList<CustomCurrencyInfo> RegisteredCurrencies => _registeredCurrencies;
        public static int _nextAutoID = 0;
        public override void OnModLoad()
        {
            _registeredCurrencies = [];
            _nextAutoID = 0;
            RegisterNativeCurrency(Language.GetTextValue("Currency.Copper"), CustomCurrencyID.None, ItemID.CopperCoin);
            RegisterNativeCurrency(Language.GetTextValue("Currency.DefenderMedals"), CustomCurrencyID.DefenderMedals, ItemID.DefenderMedal);
        }
        public override void PostSetupContent()
        {
            AutoDiscoverAllCurrencies();
        }
        public static void AutoDiscoverAllCurrencies()
        {
            var currenciesField = typeof(CustomCurrencyManager).GetField("_currencies",
                BindingFlags.Static | BindingFlags.NonPublic);
            if (currenciesField == null) return;
            var allCurrencies = (Dictionary<int, CustomCurrencySystem>)currenciesField.GetValue(null);
            foreach (var kvp in allCurrencies)
            {
                int currencyID = kvp.Key;
                CustomCurrencySystem currencySystem = kvp.Value;
                if (_registeredCurrencies.Any(x => x.CurrencyID == currencyID))
                    continue;
                int iconItemID = GetIconItemIDFromSystem(currencySystem);
                string currencyName = "";
                if (iconItemID > 0)
                {
                    currencyName = Lang.GetItemNameValue(iconItemID);
                }
                if (string.IsNullOrEmpty(currencyName))
                {
                    currencyName = GetFallbackName(currencySystem, currencyID);
                    if (iconItemID <= 0) iconItemID = ItemID.PlatinumCoin;
                }
                _registeredCurrencies.Add(new CustomCurrencyInfo
                {
                    Name = currencyName,
                    CurrencyID = currencyID,
                    IconItemID = iconItemID
                });
                if (currencyID >= _nextAutoID)
                {
                    _nextAutoID = currencyID + 1;
                }
            }
        }
        public static int GetIconItemIDFromSystem(CustomCurrencySystem system)
        {
            if (system == null) return 0;
            Type systemType = system.GetType();
            FieldInfo valuePerUnitField = typeof(CustomCurrencySystem).GetField("_valuePerUnit", BindingFlags.Instance | BindingFlags.NonPublic);
            if (valuePerUnitField != null)
            {
                Dictionary<int, int> dict = valuePerUnitField.GetValue(system) as Dictionary<int, int>;
                if (dict != null && dict.Count > 0)
                {
                    return dict.Keys.First();
                }
            }
            FieldInfo singleCoinField = systemType.GetField("_coinItemID", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);
            if (singleCoinField != null && singleCoinField.FieldType == typeof(int))
            {
                return (int)singleCoinField.GetValue(system);
            }
            return 0;
        }
        public static string GetFallbackName(CustomCurrencySystem system, int id)
        {
            string typeName = system.GetType().Name;
            if (typeName.EndsWith("Currency")) typeName = typeName[..^8];
            if (typeName.EndsWith("System")) typeName = typeName[..^6];
            return $"{typeName} (ID:{id})";
        }
        public override void Unload()
        {
            _registeredCurrencies = null;
        }
        public static void RegisterNativeCurrency(string name, int fixedID, int iconItemID)
        {
            _registeredCurrencies.Add(new CustomCurrencyInfo
            {
                Name = name,
                CurrencyID = fixedID,
                IconItemID = iconItemID
            });
            if (fixedID >= _nextAutoID)
            {
                _nextAutoID = fixedID + 1;
            }
        }
        public static int RegisterCurrency(string name, int iconItemID)
        {
            var existing = _registeredCurrencies.Find(x => x.Name == name && x.IconItemID == iconItemID);
            if (existing != null) return existing.CurrencyID;
            if (_registeredCurrencies.Count > 0)
            {
                int maxId = _registeredCurrencies.Max(c => c.CurrencyID);
                if (_nextAutoID <= maxId) _nextAutoID = maxId + 1;
            }
            int newID = _nextAutoID;
            _registeredCurrencies.Add(new CustomCurrencyInfo
            {
                Name = name,
                CurrencyID = newID,
                IconItemID = iconItemID
            });
            _nextAutoID++;
            return newID;
        }
    }
}