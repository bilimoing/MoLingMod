﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;
using Terraria.UI;
using YamlDotNet.Serialization;
using YamlDotNet.Serialization.NamingConventions;
using 自定义卖商品.Common.Helpers;
using 自定义卖商品.Common.UIs;

namespace 自定义卖商品.Common.Systems
{
    public class ShopCustomizerSystem : ModSystem
    {
        internal UserInterface shopInterface;
        internal ShopCustomizerUI shopUI;
        public Dictionary<int, Dictionary<string, List<ShopItemEntry>>> ShopItems = [];
        public Dictionary<int, bool> HasCustomShopItems = [];

        public static string ConfigFolderPath => Path.Combine(Main.SavePath, "自定义卖商品");
        public static string ConfigFilePath => Path.Combine(ConfigFolderPath, "ShopExport.yaml");

        public override void Load()
        {
            if (!Main.dedServ)
            {
                shopUI = new ShopCustomizerUI(this);
                shopInterface = new UserInterface();
            }
        }

        public override void Unload()
        {
            shopUI = null;
            shopInterface = null;
        }

        public void ExportConfig()
        {
            try
            {
                if (!Directory.Exists(ConfigFolderPath))
                    Directory.CreateDirectory(ConfigFolderPath);

                var exportList = new List<ExportDataModel>();
                foreach (var npcEntry in ShopItems)
                {
                    if (npcEntry.Value.Count == 0) continue;

                    string npcName = Lang.GetNPCNameValue(npcEntry.Key);
                    var npcData = new ExportDataModel
                    {
                        NPCID = npcEntry.Key,
                        NPCName = npcName
                    };

                    foreach (var shopEntry in npcEntry.Value)
                    {
                        var shopData = new ShopDataModel { ShopName = shopEntry.Key };

                        foreach (var item in shopEntry.Value)
                        {
                            string itemName = Lang.GetItemNameValue(item.ItemID);
                            shopData.Items.Add(new ItemDataModel
                            {
                                ItemID = item.ItemID,
                                ItemName = itemName,
                                C1Type = item.Condition1Type,
                                C1Val = item.Condition1Value,
                                C2Type = item.Condition2Type,
                                C2Val = item.Condition2Value,
                                CustomPrice = item.CustomPrice,
                                CurrencyID = item.CurrencyID
                            });
                        }
                        npcData.Shops.Add(shopData);
                    }
                    exportList.Add(npcData);
                }

                var serializer = new SerializerBuilder()
                    .WithNamingConvention(CamelCaseNamingConvention.Instance)
                    .ConfigureDefaultValuesHandling(DefaultValuesHandling.OmitDefaults)
                    .Build();

                string yaml = serializer.Serialize(exportList);
                File.WriteAllText(ConfigFilePath, yaml);

                Main.NewText($"配置已导出至: {ConfigFilePath}", Color.Green);
            }
            catch (Exception ex)
            {
                Main.NewText($"导出失败: {ex.Message}", Color.Red);
                Mod.Logger.Error(ex);
            }
        }

        public void ImportConfig()
        {
            try
            {
                if (!File.Exists(ConfigFilePath))
                {
                    Main.NewText("未找到导出文件！请确保文件位于: " + ConfigFilePath, Color.Orange);
                    return;
                }

                string yaml = File.ReadAllText(ConfigFilePath);


                var deserializer = new DeserializerBuilder()
                    .WithNamingConvention(CamelCaseNamingConvention.Instance)
                    .Build();

                var importList = deserializer.Deserialize<List<ExportDataModel>>(yaml);

                if (importList == null) return;

                ShopItems.Clear();
                HasCustomShopItems.Clear();

                foreach (var npcData in importList)
                {
                    if (!ShopItems.ContainsKey(npcData.NPCID))
                        ShopItems[npcData.NPCID] = new Dictionary<string, List<ShopItemEntry>>();

                    HasCustomShopItems[npcData.NPCID] = true;

                    foreach (var shopData in npcData.Shops)
                    {
                        var itemList = new List<ShopItemEntry>();
                        foreach (var itemData in shopData.Items)
                        {
                            itemList.Add(new ShopItemEntry(
                                itemData.ItemID,
                                itemData.C1Type,
                                itemData.C1Val,
                                itemData.C2Type,
                                itemData.C2Val,
                                itemData.CustomPrice,
                                itemData.CurrencyID
                            ));
                        }
                        ShopItems[npcData.NPCID][shopData.ShopName] = itemList;
                    }
                }

                Main.NewText("配置导入成功！", Color.Green);
            }
            catch (Exception ex)
            {
                Main.NewText($"导入失败: {ex.Message}", Color.Red);
                Mod.Logger.Error(ex);
            }
        }

        public void UpdateItemCurrency(int npcID, string shopName, int itemIndex, int newCurrencyID)
        {
            if (ShopItems.TryGetValue(npcID, out var shopDict) && shopDict.TryGetValue(shopName, out var items))
            {
                if (itemIndex >= 0 && itemIndex < items.Count)
                {
                    items[itemIndex].CurrencyID = newCurrencyID;
                }
            }
        }

        public override void SaveWorldData(TagCompound tag)
        {
            if (ShopItems.Count > 0)
            {
                var shopData = new List<TagCompound>();
                foreach (var npcEntry in ShopItems)
                {
                    var npcTag = new TagCompound { ["NPCID"] = npcEntry.Key };
                    var shopsList = new List<TagCompound>();
                    foreach (var shopEntry in npcEntry.Value)
                    {
                        var itemsTagList = new List<TagCompound>();
                        foreach (var item in shopEntry.Value)
                        {
                            itemsTagList.Add(new TagCompound
                            {
                                ["ID"] = item.ItemID,
                                ["CType1"] = item.Condition1Type,
                                ["CVal1"] = item.Condition1Value,
                                ["CType2"] = item.Condition2Type,
                                ["CVal2"] = item.Condition2Value,
                                ["Price"] = item.CustomPrice,
                                ["CurrencyID"] = item.CurrencyID
                            });
                        }
                        shopsList.Add(new TagCompound
                        {
                            ["ShopName"] = shopEntry.Key,
                            ["ItemsV3"] = itemsTagList
                        });
                    }
                    npcTag["Shops"] = shopsList;
                    shopData.Add(npcTag);
                }
                tag["CustomShopData_V3"] = shopData;
            }
            if (HasCustomShopItems.Count > 0)
            {
                var flags = new List<TagCompound>();
                foreach (var kvp in HasCustomShopItems)
                {
                    flags.Add(new TagCompound { ["NPCID"] = kvp.Key, ["HasCustom"] = kvp.Value });
                }
                tag["CustomShopFlags"] = flags;
            }
        }

        public override void LoadWorldData(TagCompound tag)
        {
            ShopItems.Clear();
            HasCustomShopItems.Clear();
            if (tag.ContainsKey("CustomShopData_V3"))
            {
                var shopData = tag.GetList<TagCompound>("CustomShopData_V3");
                foreach (var npcTag in shopData)
                {
                    int npcID = npcTag.GetInt("NPCID");
                    var shopsList = npcTag.GetList<TagCompound>("Shops");
                    var npcDict = new Dictionary<string, List<ShopItemEntry>>();
                    foreach (var shopTag in shopsList)
                    {
                        string shopName = shopTag.GetString("ShopName");
                        var itemsTagList = shopTag.GetList<TagCompound>("ItemsV3");
                        var items = new List<ShopItemEntry>();
                        foreach (var itemTag in itemsTagList)
                        {
                            items.Add(new ShopItemEntry(
                                itemTag.GetInt("ID"),
                                itemTag.GetInt("CType1"),
                                itemTag.GetInt("CVal1"),
                                itemTag.GetInt("CType2"),
                                itemTag.GetInt("CVal2"),
                                itemTag.ContainsKey("Price") ? itemTag.GetInt("Price") : -1,
                                itemTag.ContainsKey("CurrencyID") ? itemTag.GetInt("CurrencyID") : 0
                            ));
                        }
                        npcDict[shopName] = items;
                    }
                    ShopItems[npcID] = npcDict;
                }
            }
            else if (tag.ContainsKey("CustomShopData_V2"))
            {
                var shopData = tag.GetList<TagCompound>("CustomShopData_V2");
                foreach (var npcTag in shopData)
                {
                    int npcID = npcTag.GetInt("NPCID");
                    var shopsList = npcTag.GetList<TagCompound>("Shops");
                    var npcDict = new Dictionary<string, List<ShopItemEntry>>();
                    foreach (var shopTag in shopsList)
                    {
                        string shopName = shopTag.GetString("ShopName");
                        var itemsTagList = shopTag.GetList<TagCompound>("ItemsV2");
                        var items = new List<ShopItemEntry>();
                        foreach (var itemTag in itemsTagList)
                        {
                            items.Add(new ShopItemEntry(
                                itemTag.GetInt("ID"),
                                itemTag.GetInt("CType"),
                                itemTag.GetInt("CVal")
                            ));
                        }
                        npcDict[shopName] = items;
                    }
                    ShopItems[npcID] = npcDict;
                }
            }
            else if (tag.ContainsKey("CustomShopData"))
            {
                var shopData = tag.GetList<TagCompound>("CustomShopData");
                foreach (var npcTag in shopData)
                {
                    int npcID = npcTag.GetInt("NPCID");
                    var npcDict = new Dictionary<string, List<ShopItemEntry>>();
                    if (npcTag.ContainsKey("Items"))
                    {
                        var oldItems = npcTag.GetIntArray("Items").ToList();
                        npcDict["Shop"] = [.. oldItems.Select(id => new ShopItemEntry(id))];
                    }
                    else if (npcTag.ContainsKey("Shops"))
                    {
                        var shopsList = npcTag.GetList<TagCompound>("Shops");
                        foreach (var shopTag in shopsList)
                        {
                            string shopName = shopTag.GetString("ShopName");
                            var items = shopTag.GetIntArray("Items").ToList();
                            npcDict[shopName] = [.. items.Select(id => new ShopItemEntry(id))];
                        }
                    }
                    ShopItems[npcID] = npcDict;
                }
            }
            if (tag.ContainsKey("CustomShopFlags"))
            {
                var flags = tag.GetList<TagCompound>("CustomShopFlags");
                foreach (var f in flags) HasCustomShopItems[f.GetInt("NPCID")] = f.GetBool("HasCustom");
            }
        }

        public override void NetSend(BinaryWriter writer)
        {
            writer.Write(ShopItems.Count);
            foreach (var npc in ShopItems)
            {
                writer.Write(npc.Key);
                writer.Write(npc.Value.Count);
                foreach (var shop in npc.Value)
                {
                    writer.Write(shop.Key);
                    writer.Write(shop.Value.Count);
                    foreach (var item in shop.Value)
                    {
                        writer.Write(item.ItemID);
                        writer.Write(item.Condition1Type);
                        writer.Write(item.Condition1Value);
                        writer.Write(item.Condition2Type);
                        writer.Write(item.Condition2Value);
                        writer.Write(item.CustomPrice);
                        writer.Write(item.CurrencyID);
                    }
                }
            }
            writer.Write(HasCustomShopItems.Count);
            foreach (var kvp in HasCustomShopItems) { writer.Write(kvp.Key); writer.Write(kvp.Value); }
        }

        public override void NetReceive(BinaryReader reader)
        {
            ShopItems.Clear();
            HasCustomShopItems.Clear();
            int npcCount = reader.ReadInt32();
            for (int i = 0; i < npcCount; i++)
            {
                int npcID = reader.ReadInt32();
                int shopCount = reader.ReadInt32();
                var npcDict = new Dictionary<string, List<ShopItemEntry>>();
                for (int s = 0; s < shopCount; s++)
                {
                    string name = reader.ReadString();
                    int itemCount = reader.ReadInt32();
                    var list = new List<ShopItemEntry>();
                    for (int j = 0; j < itemCount; j++)
                    {
                        list.Add(new ShopItemEntry(
                            reader.ReadInt32(),
                            reader.ReadInt32(),
                            reader.ReadInt32(),
                            reader.ReadInt32(),
                            reader.ReadInt32(),
                            reader.ReadInt32(),
                            reader.ReadInt32()));
                    }
                    npcDict[name] = list;
                }
                ShopItems[npcID] = npcDict;
            }
            int flagCount = reader.ReadInt32();
            for (int i = 0; i < flagCount; i++) HasCustomShopItems[reader.ReadInt32()] = reader.ReadBoolean();
        }

        public void UpdateItemPrice(int npcID, string shopName, int itemIndex, int newPrice)
        {
            if (ShopItems.TryGetValue(npcID, out var shopDict) && shopDict.TryGetValue(shopName, out var items))
            {
                if (itemIndex >= 0 && itemIndex < items.Count)
                {
                    items[itemIndex].CustomPrice = newPrice;
                }
            }
        }

        public override void ClearWorld()
        {
            ShopItems.Clear();
            HasCustomShopItems.Clear();
        }

        public override void UpdateUI(GameTime gameTime)
        {
            if (shopInterface?.CurrentState != null)
                shopInterface.Update(gameTime);
        }

        public override void ModifyInterfaceLayers(List<GameInterfaceLayer> layers)
        {
            int index = layers.FindIndex(layer => layer.Name.Equals("Vanilla: Mouse Text"));
            if (index != -1)
            {
                layers.Insert(index, new LegacyGameInterfaceLayer(
                    "自定义卖商品: UI",
                    delegate
                    {
                        if (shopInterface?.CurrentState != null)
                            shopInterface.Draw(Main.spriteBatch, new GameTime());
                        return true;
                    },
                    InterfaceScaleType.UI)
                );
            }
        }

        public void ShowUI()
        {
            shopInterface?.SetState(shopUI);
            shopUI?.OnInitialize();
        }

        public void HideUI() => shopInterface?.SetState(null);

        public void ToggleUI()
        {
            if (shopInterface?.CurrentState != null)
            {
                HideUI();
            }
            else
            {
                ShowUI();
            }
        }

        public void AddShopItem(int npcID, string shopName, int itemID)
        {
            if (!ShopItems.TryGetValue(npcID, out var shopDict))
            {
                shopDict = new();
                ShopItems[npcID] = shopDict;
                HasCustomShopItems[npcID] = true;
            }
            if (!shopDict.TryGetValue(shopName, out var items))
            {
                items = new List<ShopItemEntry>();
                shopDict[shopName] = items;
            }
            if (!items.Any(x => x.ItemID == itemID))
            {
                items.Add(new ShopItemEntry(itemID));
            }
        }

        public void RemoveShopItem(int npcID, string shopName, int itemID)
        {
            if (ShopItems.TryGetValue(npcID, out var shopDict))
            {
                if (shopDict.TryGetValue(shopName, out var items))
                {
                    items.RemoveAll(x => x.ItemID == itemID);
                }
                bool hasAny = shopDict.Any(kvp => kvp.Value.Count > 0);
                if (!hasAny)
                {
                    HasCustomShopItems[npcID] = false;
                }
            }
        }

        public void UpdateItemCondition(int npcID, string shopName, int itemIndex, int conditionSlot, int cType, int cVal)
        {
            if (ShopItems.TryGetValue(npcID, out var shopDict) && shopDict.TryGetValue(shopName, out var items))
            {
                if (itemIndex >= 0 && itemIndex < items.Count)
                {
                    if (conditionSlot == 1)
                    {
                        items[itemIndex].Condition1Type = cType;
                        items[itemIndex].Condition1Value = cVal;
                    }
                    else if (conditionSlot == 2)
                    {
                        items[itemIndex].Condition2Type = cType;
                        items[itemIndex].Condition2Value = cVal;
                    }
                }
            }
        }

        public List<ShopItemEntry> GetShopItems(int npcID, string shopName)
        {
            if (ShopItems.TryGetValue(npcID, out var shopDict) && shopDict.TryGetValue(shopName, out var items))
            {
                return items;
            }
            return [];
        }

        public bool HasCustomShop(int npcID)
        {
            return HasCustomShopItems.ContainsKey(npcID) && HasCustomShopItems[npcID];
        }
    }
}