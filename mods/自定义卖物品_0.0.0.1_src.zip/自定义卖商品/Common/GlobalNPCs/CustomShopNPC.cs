using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using 自定义卖商品.Common.Configs;
using 自定义卖商品.Common.Helpers;
using 自定义卖商品.Common.Systems;

namespace 自定义卖商品.Common.GlobalNPCs
{
    public class CustomShopNPC : GlobalNPC
    {
        public override void ModifyShop(NPCShop shop)
        {
            base.ModifyShop(shop);
            var config = ModContent.GetInstance<ShopConfig>();
            if (config is { RemoveOriginalItems: true })
            {
                foreach (NPCShop.Entry e in shop.Entries)
                {
                    e.Disable();
                }
            }
        }

        public override void ModifyActiveShop(NPC npc, string shopName, Item[] items)
        {
            var system = ModContent.GetInstance<ShopCustomizerSystem>();
            if (system != null && system.ShopItems.TryGetValue(npc.type, out var npcShops))
            {
                List<ShopItemEntry> customEntries = null;
                if (npcShops.TryGetValue(shopName, out var list))
                {
                    customEntries = list;
                }
                else
                {
                    foreach (var key in npcShops.Keys)
                    {
                        if (key.Contains(shopName, System.StringComparison.OrdinalIgnoreCase) ||
                            shopName.Contains(key, System.StringComparison.OrdinalIgnoreCase))
                        {
                            customEntries = npcShops[key];
                            break;
                        }
                    }
                }

                if (customEntries is { Count: > 0 })
                {
                    List<Item> finalInventory = [];
                    var config = ModContent.GetInstance<ShopConfig>();
                    if (config is not { RemoveOriginalItems: true })
                    {
                        for (int i = 0; i < items.Length; i++)
                        {
                            if (items[i] != null && items[i].type != ItemID.None) finalInventory.Add(items[i]);
                        }
                    }

                    foreach (var entry in customEntries)
                    {
                        if (entry.ItemID > 0)
                        {
                            bool shouldSell = true;
                            if (entry.Condition1Type > 0)
                            {
                                if (!ConditionRegistry.Check(entry.Condition1Type, entry.Condition1Value))
                                {
                                    shouldSell = false;
                                }
                            }

                            if (shouldSell && entry.Condition2Type > 0)
                            {
                                if (!ConditionRegistry.Check(entry.Condition2Type, entry.Condition2Value))
                                {
                                    shouldSell = false;
                                }
                            }

                            if (shouldSell)
                            {
                                Item newItem = new();
                                newItem.SetDefaults(entry.ItemID);

                                if (entry.CustomPrice != -1)
                                {
                                    newItem.shopCustomPrice = entry.CustomPrice;
                                }

                                if (entry.CurrencyID == CustomCurrencyID.None)
                                {
                                    newItem.shopSpecialCurrency = -1;
                                }
                                else
                                {
                                    newItem.shopSpecialCurrency = entry.CurrencyID;
                                }

                                finalInventory.Add(newItem);
                            }
                        }
                    }

                    for (int i = 0; i < items.Length; i++)
                    {
                        items[i] = new Item();
                    }

                    for (int i = 0; i < finalInventory.Count; i++)
                    {
                        if (i < items.Length)
                        {
                            items[i] = finalInventory[i];
                        }
                    }
                }
            }
        }
    }
}