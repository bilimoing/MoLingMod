﻿using Terraria.GameInput;
using Terraria.ModLoader;
using 自定义卖商品.Common.Systems;
namespace 自定义卖商品.Common.Players
{
    public class OpenUI : ModPlayer
    {
        public override void ProcessTriggers(TriggersSet triggersSet)
        {
            if (KeybindSystem.OpenUI.JustPressed)
            {
                var system = ModContent.GetInstance<ShopCustomizerSystem>();
                system.ToggleUI();
            }
        }
    }
}
