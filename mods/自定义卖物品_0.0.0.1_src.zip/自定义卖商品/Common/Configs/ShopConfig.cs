﻿using System.ComponentModel;
using Terraria.ModLoader.Config;
namespace 自定义卖商品.Common.Configs
{
    public class ShopConfig : ModConfig
    {
        public override ConfigScope Mode => ConfigScope.ServerSide;
        [DefaultValue(false)]
        [ReloadRequired]
        public bool RemoveOriginalItems;
    }
}