using MLManaFruit.Common.Players;
using System;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace MLManaFruit.Content.Items;

public class ManaFruit : ModItem
{
    public override void SetStaticDefaults()
    {
        Item.ResearchUnlockCount = 10;
    }
    
    public override void SetDefaults()
    {
        Item.maxStack = Item.CommonMaxStack;
        Item.consumable = true;
        Item.width = 18;
        Item.height = 18;
        Item.useStyle = ItemUseStyleID.HoldUp;
        Item.useTime = 30;
        Item.UseSound = SoundID.Item4;
        Item.useAnimation = 30;
        Item.rare = ItemRarityID.Lime;
        Item.value = Item.sellPrice(0, 2);
    }
    
    public override bool CanUseItem(Player player)
    {
        return player.statMana >= 200 && player.GetModPlayer<ManaFruitPlayer>().goldenStars switch
        {
            < ManaFruitPlayer.goldenStarsMax => true,
            _ => false,
        };
    }

    public override Nullable<bool> UseItem(Player player)/* tModPorter Suggestion: Return null instead of false */
    {
        player.ManaEffect(5);
        player.statManaMax2 += 5;
        player.GetModPlayer<ManaFruitPlayer>().goldenStars += 1;
        return true;
    }
}