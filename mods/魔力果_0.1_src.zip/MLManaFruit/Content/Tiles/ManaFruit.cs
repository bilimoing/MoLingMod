﻿using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ModLoader;
using Terraria.ObjectData;

namespace MLManaFruit.Content.Tiles;

public class ManaFruit : ModTile
{
    public override void SetStaticDefaults()
    {
        Main.tileOreFinderPriority[Type] = 810;
        Main.tileShine[Type] = 600;
        Main.tileShine2[Type] = true;
        Main.tileSpelunker[Type] = true;
        Main.tileFrameImportant[Type] = true;
        Main.tileCut[Type] = true;
        Main.tileLavaDeath[Type] = true;
        Main.tileNoAttach[Type] = true;
        Main.tileSolid[Type] = false;
        TileObjectData.newTile.CopyFrom(TileObjectData.Style2x2);
        TileObjectData.newTile.CoordinateHeights = new[] { 16, 18 };
        TileObjectData.newTile.DrawYOffset = 2;
        TileObjectData.newTile.StyleHorizontal = true;
        TileObjectData.newTile.RandomStyleRange = 3;
        TileObjectData.addTile(Type);
        RegisterItemDrop(ModContent.ItemType<Items.ManaFruit>());
        AddMapEntry(new Color(200, 200, 200));
    }
}