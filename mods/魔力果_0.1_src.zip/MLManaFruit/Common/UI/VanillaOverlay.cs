﻿using System.Collections.Generic;
using Microsoft.Xna.Framework.Graphics;
using MLManaFruit.Common.Players;
using ReLogic.Content;
using Terraria;
using Terraria.GameContent;
using Terraria.ModLoader;

namespace MLManaFruit.Common.UI;

public class VanillaOverlay : ModResourceOverlay
{
    private Dictionary<string, Asset<Texture2D>> vanillaAssetCache = [];
    private Asset<Texture2D> starTexture, barsFillingTexture;

    public override void PostDrawResource(ResourceOverlayDrawContext context)
    {
        var asset = context.texture;
        string fancyFolder = "Images/UI/PlayerResourceSets/FancyClassic/";
        string barsFolder = "Images/UI/PlayerResourceSets/HorizontalBars/";

        if (Main.LocalPlayer.GetModPlayer<ManaFruitPlayer>().goldenStars > 0)
        {
            if (asset == TextureAssets.Mana)
            {
                context.texture = starTexture ??=
                    ModContent.Request<Texture2D>("MLManaFruit/Assets/Textures/Players/Mana");
                context.Draw();
            }
            else if (CompareAssets(asset, fancyFolder + "Star_Fill"))
            {
                context.texture = starTexture ??=
                    ModContent.Request<Texture2D>("MLManaFruit/Assets/Textures/Players/Star_Fill");
                context.Draw();
            }
            else if (CompareAssets(asset, barsFolder + "MP_Fill"))
            {
                context.texture = barsFillingTexture ??=
                    ModContent.Request<Texture2D>("MLManaFruit/Assets/Textures/Players/MP_Fill");
                context.Draw();
            }
        }
    }

    private bool CompareAssets(Asset<Texture2D> existingAsset, string compareAssetPath)
    {
        if (!vanillaAssetCache.TryGetValue(compareAssetPath, out var asset))
        {
            asset = vanillaAssetCache[compareAssetPath] = Main.Assets.Request<Texture2D>(compareAssetPath);
        }

        return existingAsset == asset;
    }
}