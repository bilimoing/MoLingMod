using Terraria.ModLoader;
using Terraria.ModLoader.IO;

namespace MLManaFruit.Common.Players;

public class ManaFruitPlayer : ModPlayer
{
    public int goldenStars;
    public const int goldenStarsMax = 20;

    public override void ResetEffects()
    {
        Player.statManaMax2 += 5 * goldenStars;
    }

    public override void SaveData(TagCompound tag)
    {
        tag["GStars"] = goldenStars;
    }

    public override void LoadData(TagCompound tag)
    {
        goldenStars = tag.GetInt("GStars");
    }
    
    public override void SyncPlayer(int toWho, int fromWho, bool newPlayer)
    {
        ModPacket packet = Mod.GetPacket();
        packet.Write((byte)Player.whoAmI);
        packet.Write(goldenStars);
        packet.Send(toWho, fromWho);
    }
}