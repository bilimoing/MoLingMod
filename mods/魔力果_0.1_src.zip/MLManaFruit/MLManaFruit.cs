using Terraria.ModLoader;

namespace MLManaFruit
{
	public class MLManaFruit : Mod
	{
	}
}
